#!/bin/bash
###########################################
# gw_user_edir_delete.sh                  #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.5                            #
# Modify date: 12/7/2020                  #
###########################################
# Allows for a eDirectory & GroupWise Account to be Deleted 

declare -i ALL_SET=0
declare -i SHOW_HELP_SCREEN=0
declare GW_SCRIPT_EXCLUDE_FILE=""
declare CURL_OUTPUT_MODE="--silent"
TEMP_FILE_DIRECTORY="/var/tmp"

declare -i USER_HAS_DIRECTORY_ASSIGNMENT=0
declare -i ALLOW_MULTIPLE_WORD_INPUT=1
declare -i PROCESS_MULTIPLE_USERS=0
declare USERID_IN_LIST=""
declare USERID_IN=""
declare USERID_IN_LOWER=""
declare NICKNAME_IN_ORIGINAL=""
declare NICKNAME_IN=""
NICKNAME_POST_OFFICE_IN_LOWER=""
NICKNAME_POST_OFFICE_IN_UPPER=""
declare -i NICKNAME_IN_PROCESSED=0
declare -i CONFIRM_DELETE_IN=0

declare -i USERID_IN_SET=0
declare -i NICKNAME_IN_SET=0
declare -i POST_OFFICE_IN_SET=0
declare -i DOMAIN_IN_SET=0
declare -i USER_POST_OFFICE_IN_SET=0
declare -i NICKNAME_POST_OFFICE_IN_SET=0
declare -i SKIP_LIST_USER_AFTER_USER_ADD=0
declare -i PARTICIPATION_TYPE=4
declare -i EXCLUDE_GROUP_OFF=0
declare -i REPLICATION_PAUSE_TIME=30
declare -i GW_USER_ACCOUNT_EDIR_OBJECT_FOUND=0
GW_USER_ACCOUNT_EDIR_OBJECT=""

declare GW_EDIR_TREE_NAME="NO_TREE_SPECIFIED"
declare -i GW_EDIR_TREE_NAME_SET=0
declare -i USER_EDIR_OBJECT_FOUND="0"
declare USER_LDAP_OBJECT="NO_USER_OBJECT_FOUND"


declare DOMAIN_IN=""

while getopts "i:u:p:d:r:t:eshv" opt; do
  case ${opt} in
    u) USERID_IN="$OPTARG"
	USERID_IN_SET=1
	USERID_IN_LOWER=`echo "${USERID_IN}" | tr [A-Z] [a-z]`
      ;;
    p) USER_POST_OFFICE_IN="$OPTARG"
	POST_OFFICE_IN="$OPTARG"
	USER_POST_OFFICE_IN_SET=1
	USER_POST_OFFICE_IN_LOWER=`echo "${USER_POST_OFFICE_IN}" | tr [A-Z] [a-z]`
      ;;
    d) DOMAIN_IN="$OPTARG"
	DOMAIN_IN_SET=1
      ;;
    i) INPUT_IN="$OPTARG"
	CONFIRM_DELETE_IN=1
      ;;
    r) REPLICATION_PAUSE_TIME="$OPTARG"
      ;;
    s) SKIP_LIST_USER_AFTER_USER_ADD=1
      ;;
    e) EXCLUDE_GROUP_OFF=1
      ;;
    t) GW_EDIR_TREE_NAME="$OPTARG"
	GW_EDIR_TREE_NAME_SET=1
      ;;
    h) SHOW_HELP_SCREEN=1
      ;;
    v) CURL_OUTPUT_MODE=""
      ;;
  esac
done

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"



### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "Delete GroupWise/eDirectory User Script"
echo ""
echo "Script usage:     $0 [options]"
echo ""
echo "Example:          $0 -p <user post office> -u <GroupWise userid> -i <confirm word>"
echo ""
echo "Example:          $0 -p po1 -u jdoe -i <confirm word>"
echo ""
echo "Help:             $0 -h"
echo ""
}



### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then
echo "GW_ADMIN_SERVICE_ADDRESS=\"172.0.0.0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then
GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"
fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then

echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}

fi

}

function CHECK_GWADMIN_SERVICE()
{

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

CURL_TRY=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

AUTHENTICATION_WORKED=`echo $?`

if [ ${AUTHENTICATION_WORKED} -ne 0 ]
then
echo ""
echo "Error authenticating to GroupWise Admnistration Service"
echo ""
exit 1
fi

}

# Process exclusions file
function PROCESS_EXCLUSIONS()
{


if [ $EXCLUDE_GROUP_OFF -eq 1 ]
then
return
fi

declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo ""
echo "Error: Exclusions Check File does not exist"
echo ""
return
fi

USERID_IN_LOWER=`echo "${USERID_IN}" | tr [A-Z] [a-z]`

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`


if [ -z "${USER_RECORD}" ]
then
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo ""
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
echo ""
exit 1
fi

done < ${GW_SCRIPT_EXCLUDE_FILE}

}

function GET_EXCLUDE_GROUP_MEMBERSHIP()
{

if [ $EXCLUDE_GROUP_OFF -eq 1 ]
then
return
fi
declare -i GW_EXCLUDE_GROUP_ENABLED=0

source ${GW_SCRIPT_SETTINGS_FILE}

if [ $GW_EXCLUDE_GROUP_ENABLED -eq 0 ]
then
return
fi

if [ ${GW_EXCLUDE_GROUP_NAME} == 'exclude_group_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} == 'exclude_group_post_office_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's post office name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_DOMAIN_NAME} == 'exclude_group_domain_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's domain name"
echo ""
exit 1
fi


BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="domains/${GW_EXCLUDE_GROUP_DOMAIN_NAME}/postoffices/${GW_EXCLUDE_GROUP_POST_OFFICE_NAME}/groups/${GW_EXCLUDE_GROUP_NAME}/members"

GROUP_GET_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

GROUP_GET_WORKED=`echo $?`

if [ ${GROUP_GET_WORKED} -ne 0 ]
then
echo ""
echo "Error getting exclude group information"
echo ""
exit 1
fi

declare -i GROUP_GET_OBJECT_HAS_COUNTER=`echo "${GROUP_GET_OBJECT}" | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -c "resultInfo:outOf:"`

if [ $GROUP_GET_OBJECT_HAS_COUNTER -ne 1 ]
then
echo ""
echo "Error getting exclude group membership count[1]"
echo ""
exit 1
fi

declare -i GROUP_GET_OBJECT_COUNTER=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep "resultInfo:outOf:" | awk -F ':' '{printf $3}'`

declare -i NUMBER_OF_USERS_IN_GROUP=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -ce "^name:"`

if ! [[ "${GROUP_GET_OBJECT_COUNTER}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [2]"
echo ""
exit 1
fi

if ! [[ "${NUMBER_OF_USERS_IN_GROUP}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [3]"
echo ""
exit 1
fi

if [ ${GROUP_GET_OBJECT_COUNTER} -ne ${NUMBER_OF_USERS_IN_GROUP} ]
then
echo ""
echo "Error getting exclude group membership count [4]"
echo ""
exit 1
fi

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -e "^name:"  | sed 's/name://' 1> ${TEMP_FILE_ONE}

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`

if [ -z "${USER_RECORD}" ]
then
# Skip empty lines
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo ""
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
echo ""
rm ${TEMP_FILE_ONE}
exit 1

fi

done < ${TEMP_FILE_ONE}

rm ${TEMP_FILE_ONE}

}




### Make sure the script is being called with the correct inputs ###
function CONFIRM_CORRECT_INPUT(){

let ALL_SET=USERID_IN_SET+USER_POST_OFFICE_IN_SET+CONFIRM_DELETE_IN

if [ $ALL_SET -ne 3 ]
then
SHOW_HELP
echo ""
echo "NOTE: Insufficient Input To Run Script"
echo ""
exit 1
fi

}


function VERIFY_USER_EXISTENCE()
{

source ${GW_SCRIPT_SETTINGS_FILE}

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${USER_POST_OFFICE_IN}&attrs=domain,postoffice,name"
{
USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -ne 0 ]
then
echo ""
echo "Error: Userid: ${USERID_IN} Does not Exist in Post Office: ${USER_POST_OFFICE_IN}"
echo ""
exit 1
fi
}


function DELETE_EDIR_OBJECT()
{
if [ $GW_USER_ACCOUNT_EDIR_OBJECT_FOUND -eq 0 ]
then
echo "No eDirectory User Object Associated with ${USERID_IN}"
return
fi

echo "Removing eDirectory User Object"
echo "DISTINGUISHED NAME: ${GW_USER_ACCOUNT_EDIR_OBJECT}"

source ${GW_SCRIPT_SETTINGS_FILE}

# --- Now use ldapdelete to delete the user object

{
ldapdelete -x -h ${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS} -p ${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT} -c -w $GW_EDIR_ADMIN_PASSWORD -D $GW_EDIR_ADMIN_USER dn: ${GW_USER_ACCOUNT_EDIR_OBJECT}
} 1> /dev/null 2> /dev/null

}


function GET_MAILBOX_INFO()
{
#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"
{
URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3"/mailboxstats"}'`

TEST=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`
} 1> /dev/null 2> /dev/null


declare -i EXIT_STATUS=`echo $?`


if [ $EXIT_STATUS -eq 0 ]
then

USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"


TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

echo "$USER_OBJECT" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

OBJECT_VISIBLITY=`echo "${USER_OBJECT}" | grep -Po '"visibility":"\K[^"]*'`

PHONE_NUMBER=`echo "${USER_OBJECT}" | grep -Po '"telephoneNumber":"\K[^"]*'`

FID=`echo "${USER_OBJECT}" | grep -Po '"fileId":"\K[^"]*'`

LAST_NAME=`echo "${USER_OBJECT}" | grep -Po '"surname":"\K[^"]*'`

FIRST_NAME=`echo "${USER_OBJECT}" | grep -Po '"givenName":"\K[^"]*'`

ACCOUNT_DISABLED_STATUS=`echo "${USER_OBJECT}" | grep -Po '"loginDisabled":"\K[^,]*'`

declare -i ACCOUNT_DISABLED_EXISTS=`echo "${USER_OBJECT}" | grep -c "loginDisabled"`

declare -i TITLE_EXISTS=`echo "${USER_OBJECT}" | grep -c "title"`

declare -i PHONE_NUMBER_EXISTS=`echo "${USER_OBJECT}" | grep -c "telephoneNumber"`

declare -i DEPARTMENT_EXISTS=`echo "${USER_OBJECT}" | grep -c "department"`

declare -i LDAP_DIRECTORY_SPECIFIED=`echo "${USER_OBJECT}" | grep -c "directoryId"`

declare -i ACCOUNT_EXPIRATION_EXISTS=`echo "${USER_OBJECT}" | grep -c "expirationDate"`

if [ $ACCOUNT_EXPIRATION_EXISTS -eq 1 ]
then

ACCOUNT_EXPIRATION_EPOCH=`grep "expirationDate" ${TEMP_FILE_TWO} | awk -F : '{printf $2}'`

ACCOUNT_EXPIRATION_EPOCH=${ACCOUNT_EXPIRATION_EPOCH::-3}

ACCOUNT_EXPIRATION_DATE_OF_EXPIRATION=`date -d@${ACCOUNT_EXPIRATION_EPOCH} | awk -F 00 '{printf $1}'`

ACCOUNT_EXPIRATION_YEAR_OF_EXPIRATION=`date -d@${ACCOUNT_EXPIRATION_EPOCH} | awk '{printf $NF}'`

fi


if [ $ACCOUNT_DISABLED_EXISTS -gt 0 ]
then

ACCOUNT_DISABLED_STATUS=`echo ${USER_OBJECT} | awk -F "\"loginDisabled\":" '{printf $2}' | awk -F "," '{print $1}'`

	if [ ${ACCOUNT_DISABLED_STATUS} = 'true' ]
	then
	ACCOUNT_ENABLED="No"
	else
	ACCOUNT_ENABLED="Yes"
	fi
else
ACCOUNT_ENABLED="Yes"
fi

if [ $LDAP_DIRECTORY_SPECIFIED -gt 0 ]
then
LDAP_ID_INFO=`echo "${USER_OBJECT}" | grep -Po '"ldapDn":"\K[^"]*'`
GW_USER_ACCOUNT_EDIR_OBJECT_FOUND=1
GW_USER_ACCOUNT_EDIR_OBJECT="${LDAP_ID_INFO}"
fi

RESULT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}` 1> /dev/null

THE_DATE_EPOCH_EXISTS=`echo "${RESULT}" | grep -c "lastClientLoginTime"`

THE_DATE_EPOCH=`echo "${RESULT}" | awk -F "\"lastClientLoginTime\":" '{printf $2}' | awk -F "," '{print $1}'`


if [ $THE_DATE_EPOCH -lt 2 ]
then

	LAST_LOG_DATE="This user has never logged in"
else

	if [ $THE_DATE_EPOCH_EXISTS -eq 1 ]
	then
	THE_DATE_EPOCH=`echo "${RESULT}" | awk -F "\"lastClientLoginTime\":" '{printf $2}' | awk -F "," '{print $1}'`
	LAST_LOG_DATE=`date -d@${THE_DATE_EPOCH}`
	else
	LAST_LOG_DATE="This user has never logged in"
	fi

fi

USERID_IN_UPPER=`echo "${USERID_IN}" | tr [a-z] [A-Z]`
echo ""
echo "USERID: ${USERID_IN_UPPER}"
echo "NAME:   ${FIRST_NAME} ${LAST_NAME}"


if [ $TITLE_EXISTS -eq 1 ]
then
USER_TITLE=`echo "${USER_OBJECT}" | grep -Po '"title":"\K[^"]*'`
echo "TITLE:  ${USER_TITLE}"
fi


if [ $DEPARTMENT_EXISTS -eq 1 ]
then
USER_DEPARTMENT=`echo "${USER_OBJECT}" | grep -Po '"department":"\K[^"]*'`
echo "DEPARTMENT:  ${USER_DEPARTMENT}"
fi


echo "LAST LOGIN TIME:  ${LAST_LOG_DATE}"
echo "USER VISIBILITY:  ${OBJECT_VISIBLITY}"
echo "ACCOUNT ENABLED:  ${ACCOUNT_ENABLED}"
if [ $ACCOUNT_EXPIRATION_EXISTS -eq 1 ]
then
echo "ACCOUNT EXPIRATION DATE:  ${ACCOUNT_EXPIRATION_DATE_OF_EXPIRATION} ${ACCOUNT_EXPIRATION_YEAR_OF_EXPIRATION}"
fi

if [ $PHONE_NUMBER_EXISTS -eq 1 ]
then
echo "PHONE NUMBER:  ${PHONE_NUMBER}"
fi
echo "FILE ID (FID):  ${FID}"
	if [ $LDAP_DIRECTORY_SPECIFIED -gt 0 ]
	then
echo "NETWORK ID:  ${LDAP_ID_INFO}"
	fi
echo ""

rm ${TEMP_FILE_ONE} 2> /dev/null

rm ${TEMP_FILE_TWO} 2> /dev/null
 

else
echo ""
echo "Cannot Determine The Last Login Time For: ${USERID_IN}"
echo ""
fi
}



function GET_DOMAIN()
{

if [ $DOMAIN_IN_SET -eq 1 ]
then
return
fi
TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"
TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/list/USER"

RESPONSE=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}`

echo "$RESPONSE" 1> ${TEMP_FILE_ONE} 

cat ${TEMP_FILE_ONE}  | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' 1> ${TEMP_FILE_TWO}

DOMAIN_IN=`grep "id:USER." ${TEMP_FILE_TWO} | grep -i ".${USER_POST_OFFICE_IN_LOWER}." | head -1 | awk -F id:USER. '{printf $2}' | awk -F . '{printf $1}'`

DOMAIN_IN=`echo "${DOMAIN_IN}" | tr [A-Z] [a-z]`

# echo "DOMAIN_IN = $DOMAIN_IN"

rm ${TEMP_FILE_ONE}

rm ${TEMP_FILE_TWO}

}

function GET_USER_FULL_NAME()
{
#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${USER_POST_OFFICE_IN}&attrs=domain,postoffice,name"
{
URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3"/mailboxstats"}'`

TEST=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -ne 0 ]
then
return
fi

USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

echo "$USER_OBJECT" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

LAST_NAME=`echo "${USER_OBJECT}" | grep -Po '"surname":"\K[^"]*'`

FIRST_NAME=`echo "${USER_OBJECT}" | grep -Po '"givenName":"\K[^"]*'`

echo "FULL NAME:   ${FIRST_NAME} ${LAST_NAME}"
echo ""

rm ${TEMP_FILE_ONE} 2> /dev/null

rm ${TEMP_FILE_TWO} 2> /dev/null
 
}


### Primary Function ###


function DELETE_USER()
{

TEMP_FILE_ONE=$1

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.22.tmp"

grep -wi "${USERID_IN}" $TEMP_FILE_ONE | head -1 1> $TEMP_FILE_TWO 

while read CURRENT_LINE
do

USERNAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $1}'`

USERNAME_LOWER=`echo "${USERNAME}" | tr [A-Z] [a-z]`

if [ ${USERID_IN_LOWER} = ${USERNAME_LOWER} ]
then

POST_OFFICE=`echo "${CURRENT_LINE}" | awk -F , '{printf $2}'`

POST_OFFICE_LOWER=`echo "${POST_OFFICE}" | tr [A-Z] [a-z]`

DOMAIN=`echo "${CURRENT_LINE}" | awk -F , '{printf $3}'`


	if [ ${USER_POST_OFFICE_IN_LOWER} = ${POST_OFFICE_LOWER} ]
	then
	echo ""
	echo "Removing GroupWise User Object"
	echo "USERNAME:    ${USERNAME}"
	echo "POST OFFICE: ${POST_OFFICE}"
	echo "DOMAIN:      ${DOMAIN}"
break
	fi


fi

done < ${TEMP_FILE_TWO}

rm $TEMP_FILE_ONE 2> /dev/null

rm $TEMP_FILE_TWO 2> /dev/null

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="/domains/${DOMAIN}/postoffices/${POST_OFFICE}/users/${USERNAME}"

URL="${BASEURL}${ENDPOINT}" 

{
RESPONSE=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X DELETE ${URL} -H "Content-Type: application/json"`
} 1> /dev/null 2> /dev/null


declare -i RESPONSE_HAS_ERROR=0

declare -i ERROR_CONDITION_ONE=`echo "${RESPONSE}" | grep -c "404"`

declare -i ERROR_CONDITION_TWO=`echo "${RESPONSE}" | grep -c "403"`

declare -i RESOURCE_OWNER=`echo "${RESPONSE}" | grep -c "resources"`

let RESPONSE_HAS_ERROR=ERROR_CONDITION_ONE+ERROR_CONDITION_TWO


if [ $RESPONSE_HAS_ERROR -gt 0 ]
then
echo ""
echo "Error DID NOT Delete User Object: ${USERID_IN}"
echo ""
	if [ $RESOURCE_OWNER -gt 0 ]
	then
	echo "This user seems to be a GroupWise Resource Owner"
	echo ""
	fi
else
echo ""
echo "Deleted User Object: ${USERID_IN}"
echo ""
echo "Delete Confirmed By The Word: \"${INPUT_IN}\""
echo ""
fi
}


function GET_USERS_IN_SYSTEM()
{
#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/list/user.csv?attrs=name,postoffice,domain"

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

{
curl --silent -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${BASEURL} -o ${TEMP_FILE_TWO}
} 1> /dev/null 2> ${TEMP_FILE_ONE}

declare -i EXIT_STATUS=`wc -m  ${TEMP_FILE_ONE} | awk '{printf $1}'`

if [ $EXIT_STATUS -ne 0 ]
then
echo ""
echo "Cannot Discover Users"
rm ${TEMP_FILE_ONE} 2> /dev/null
echo ""
return 1
fi

rm ${TEMP_FILE_ONE} 2> /dev/null

DELETE_USER ${TEMP_FILE_TWO}

}

main()
{

if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi

CONFIRM_CORRECT_INPUT
PROCESS_SETTINGS_FILES
CHECK_GWADMIN_SERVICE
VERIFY_USER_EXISTENCE
PROCESS_EXCLUSIONS
GET_EXCLUDE_GROUP_MEMBERSHIP
GET_DOMAIN
GET_MAILBOX_INFO
DELETE_EDIR_OBJECT
GET_USERS_IN_SYSTEM
}

main




