#!/bin/bash
 
SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"

CONFIGURE_SCRIPT="gw_cimitra_configure.sh"

declare -i CONFIGURE_SCRIPT_EXISTS=`test -f ${SCRIPT_PATH}/${CONFIGURE_SCRIPT} ; echo $?`

if [ $CONFIGURE_SCRIPT_EXISTS -ne 0 ]
then
echo ""
echo "Error: The Script ${SCRIPT_PATH}/${CONFIGURE_SCRIPT} Does Not Exist"
echo ""
exit 1
fi


cd ${SCRIPT_PATH}

# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

test -f ${GW_SCRIPT_SETTINGS_FILE}

declare -i SETTINGS_FILE_EXISTS=`echo $?`


if [ $SETTINGS_FILE_EXISTS -ne 0 ]
then
echo ""
echo "Error: The Script ${GW_SCRIPT_SETTINGS_FILE} Does Not Exist"
echo ""
exit 1
fi

/bin/bash ./${CONFIGURE_SCRIPT} "DISABLE_EXCLUDE_GROUP" 

exit 0
