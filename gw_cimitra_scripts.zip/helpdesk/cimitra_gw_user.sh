#!/usr/bin/env bash
# Author: Tay Kratzer tay@cimitra.com
# Modify Date: 2/17/2022
# Modify GroupWise User via the GroupWise Admin API

#echo "--------"
#echo $@
#echo "--------"

declare -i EXCLUDE_GROUP_TEMP_FILE_DEFINED=0
declare EXCLUDE_GROUP_TEMP_FILE=""
declare -i CHANGE_USER_INITIALIZED=0
declare -i EXCLUDE_GROUP_OFF=0
declare TEMP_FILE_DIRECTORY="/var/tmp"
declare -i USER_POST_OFFICE_SET=0
declare -i USERID_SET=0
declare -i USER_MODIFIED=0
declare -i POST_OFFICE_SET=0
declare -i DEFAULT_USER_POST_OFFICE_SET=0
declare -i DEBUG=0
declare LastUserIdChecked="nullByString"
declare UserId=""
declare UserPassword=""
declare PostOffice=""
declare GroupName=""
declare GroupPostOffice=""
declare ListUsersContext=""
declare ExpirationDate=""
declare IgnoreExcludeGroup=""
declare UserIdList=""
declare GroupDN=""
declare SearchedUserContext=""
declare -i SILENT_MODE=0
declare FULL_NETWORK_ID=""
declare -i SHOW_ADMIN_LEVEL_USER_INFO=0
declare -i OFFBOARD_USER=0
declare -i DISABLE_OFFBOARD_USER_TRACKING=0
declare GROUP_DOMAIN=""


# store arguments in a special array 
args=("$@") 
# get number of elements 
ELEMENTS=${#args[@]} 
 
declare -i USERID_LIST_EXISTS=0
# echo each element in array  
# for loop 
for (( i=0;i<$ELEMENTS;i++)); do 

	if [ $USERID_LIST_EXISTS -gt 0 ]
	then
		TheUserIdList="${args[${i}]}"
		USERID_LIST_EXISTS=0 
	fi
	USERID_LIST_EXISTS=`echo "${args[${i}]}" | grep -ic "-UserIdList"` 
done

declare -i SKIP_GROUPWISE_USER_OBJECT_CHANGE=0
declare -i SKIP_LDAP_ASSOCIATION_CHECK=0
declare -i MODIFY_USER_ATTRIBUTE=0
declare -i SKIP_USER_FULL_NAME_DISPLAY=0
declare -i BULK_USER_ACTION=0
declare -i USER_TO_GROUP_ACTION=0
declare -i SHOW_DYNAMIC_GROUP_MEMBERSHIPS=1
declare -i SHOW_HELP_MESSAGE=0
declare -i EMPTY_STRING_SENT=0
declare -i SleepTime=5
declare -i DisableUserVerify=0
declare -i DisableUserSearch=0
declare -i USER_REPORT_ALREADY_RAN=0
declare -i DISABLE_USER=0
declare -i COMPACT_OUTPUT=0
declare -i MODIFY_GROUP=0
declare -i REPORT_USER=0
declare -i ADD_USER_TO_GROUP=0
declare -i REMOVE_USER_FROM_GROUP=0
declare -i GROUP_MODIFY_COMPLETE=0
declare -i IGNORE_EXCLUDE_GROUP=0
declare -i CREATE_USER=0
declare -i REMOVE_USER=0
declare -i USER_CONTEXT_SET=0
declare -i DEFAULT_USER_CONTEXT_SET=0
declare -i THE_USER_WAS_CREATED=0
declare -i ADD_CREATED_USER_TO_GROUP=0
declare -i LIST_USERS_CONTEXT_SET=0
declare -i ModifiedUserFirstName=0
declare -i ModifiedUserLastName=0
declare -i USER_FULL_NAME_OR_USERID=0
declare -i USER_FULL_NAME_OR_USERID_OR_DN=0
declare -i USER_ACTION=0
declare -i GROUP_ACTION=0
declare -i DisableUserReport=0
declare -i REPLACE_FULL_NAME=0
declare -i WILD_CARD_SEARCH=0
declare -i SUPPRESS_STANDARD_ERROR=1
declare -i SWITCH=0
declare -i SHOW_USER_ATTRIBUTE_DISPLAY=0
declare -i SKIP_USER_USERID_DISPLAY=0
declare -i SIMPLE_DISPLAY=1
declare -i DISABLE_SHOWING_USER_FULL_NAME=0
declare -i FIRST_USER_MODIFIED=0
declare -i GROUP_POST_OFFICE_USED=0
declare -i SEACHED_FOR_USER_EXISTS=0
declare -i QUIET_MODE=0
declare -i SHOW_MAILBOX_STATS=0
declare -i SHOW_ACCOUNT_STATUS=0
declare -i SKIP_USER_REPORT=0
declare -i UserIdListPassed=`echo "$@" | grep -ic "UserIdList"`
declare -i ADD_OFFBOARD_USER_TO_GROUP=0

while [ $# -gt 0 ]; do
  case "$1" in
    --help*|-h*)
    #Show Help Screen
    SHOW_HELP_MESSAGE=1
      ;;
    -q)
    QUIET_MODE=1
      ;;
    -Debug)
    DEBUG=1
      ;;
    -SkipUserReport)
    	SKIP_USER_REPORT=1
      ;;
    -OffBoardUser)
    	OffBoardUser=1
      ;;
    -OffBoardUserGroupName)
    	OffBoardUserGroupName=$2
	ADD_OFFBOARD_USER_TO_GROUP=1
      ;;
    -OffBoardUserGroupPostOffice)
    	OffBoardUserGroupPostOffice=$2
      ;;
    -ReverseOffBoardUser)
    	ReverseOffBoardUser=1
      ;;
    -DisableOffBoardUserTracking)
	DISABLE_OFFBOARD_USER_TRACKING=1
      ;;
    -IgnoreExcludeGroup)
	# If there is an "EXCLUDE_GROUP" specified in the settings_gw.cfg file, then ignore the Exclude Group.
	IGNORE_EXCLUDE_GROUP=1
	  ;;
    -VerboseDisplay)
	# Verbose Display is a more technical display of events and eDirectory objects
	SIMPLE_DISPLAY=0
	  ;;
    -JustASwitch)
	# Just a switch that at times can be useful with Cimitra
	;;
    -ConfirmWordIn)
	# Just a switch that at times can be useful with Cimitra
	ConfirmWordIn=$2
	;;
    -JustBSwitch)
	# Just a switch that at times can be useful with Cimitra
	;;
    -JustCSwitch)
	# Just a switch that at times can be useful with Cimitra
	;;
    -JustDSwitch)
	# Just a switch that at times can be useful with Cimitra
	;;
    -JustESwitch)
	# Just a switch that at times can be useful with Cimitra
	;;
    -JustFSwitch)
	# Just a switch that at times can be useful with Cimitra
	;;
    -ShowUserAttributeDisplay)
	# A comma separated list of the attributes that should be displayed for a user
	# Example: -ShowUserAttributeDisplay "Title, Description"
	SHOW_USER_ATTRIBUTE_DISPLAY=1
	SHOW_USER_ATTRIBUTE_DISPLAY_LIST="$2"
	;;
     -ShowAccountStatus)
	ShowAccountStatus=$2
	SHOW_ACCOUNT_STATUS=1
	;;
     -ShowMailboxStats)
	ShowMailboxStats=$2
	SHOW_MAILBOX_STATS=1
	;;
    -SkipLDAPCheck)
	SKIP_LDAP_ASSOCIATION_CHECK=1
	;;
    -ShowStandardError)
	SUPPRESS_STANDARD_ERROR=0
	;;
    -SleepTime)
     # For sleep/pause actions in this script, indicate the amount in seconds default is 5 seconds.
	SleepTime="$2"
	  ;;
    -ShowAdminInfo)
     # When showing a User Report, show Admin Level Information
	SHOW_ADMIN_LEVEL_USER_INFO=1
	  ;;
    -DisableUserReport)
     # After a user is modified, a user report is run, the -DisableUserReport switch disables this functionality
	DisableUserReport="1"
	  ;;
    -DefaultUserSearchPostOffice)
     # If the -PostOffice parameter is not specified, then if the -DefaultUserSearchPostOffice parameter is specified, it will be used to determine the path to an object
	DefaultUserSearchPostOffice="$2"
	DEFAULT_USER_POST_OFFICE_SET="1"
	  ;;
    -UserId)
     # When modifying a user, use the -UserId parameter, along with the -PostOffice or -DefaultUserSearchPostOffice parameter.
     # Example: -UserId "jdoe"
	UserId="$2"
	USERID_SET=1
	USER_ACTION=1
	USERID_IN_LOWER=`echo "$UserId" | tr [A-Z] [a-z]`
	  ;;
    -PostOffice)
     # When modifying a user, use the -UserId parameter, along with the -PostOffice or -DefaultUserSearchPostOffice parameter.
     # Example: -PostOffice "po1.domain1"
	PostOffice="$2"
	POST_OFFICE_IN_SET="1"
	POST_OFFICE_SET="1"
	POST_OFFICE_IN_UPPER=`echo ${PostOffice} | tr [a-z] [A-Z]`
	POST_OFFICE_IN_LOWER=`echo ${PostOffice} | tr [A-Z] [a-z]`
	  ;;
    -DisableUser)
      DisableUser=1
	  ;;
    -EnableUser)
      EnableUser=1
	  ;;
    -UserActivate)
      UserActivate=1
	  ;;
    -UserDeactivate)
      UserDeactivate=1
	  ;;
    -ExpirationDate)
     ExpirationDate="$2"
	  ;;
    -RemoveExpiration)
     RemoveExpiration=1
	  ;;
    -UserVisibility)
     UserVisibility="$2"
	  ;;
    -UserPassword)
     UserPassword="$2"
	  ;;
    -ModifyUser)
      ModifyUser=1
	  ;;
    -NewPostOffice)
      NewPostOffice="$2"
	  ;;
    -DefaultPassword)
      DefaultPassword="$2"
	  ;;
    -Action)
      Action="$2"
	  ;;
    -Title)
      Title="$2"
	  ;;
    -OfficePhone)
      OfficePhone="$2"
	  ;;
    -OtherPhone)
      OtherPhone="$2"
	  ;;
    -HomePhone)
      HomePhone="$2"
	  ;;
    -MobilePhone)
      MobilePhone="$2"
	  ;;
    -FaxNumber)
      FaxNumber="$2"
	  ;;
    -PagerNumber)
      PagerNumber="$2"
	  ;;
    -GenerationQualifier)
      GenerationQualifier="$2"
	  ;;
    -MiddleInitial)
      MiddleInitial="$2"
	  ;;
    -NewFirstName)
      NewFirstName="$2"
	  ;;
    -NewLastName)
      NewLastName="$2"
	  ;;
    -Company)
      Company="$2"
	  ;;
    -Description)
      Description="$2"
	  ;;
    -Department)
      Department="$2"
	  ;;
    -Location)
      Location="$2"
	  ;;
    -Street)
      Street="$2"
	  ;;
    -POBox)
      POBox="$2"
	  ;;
    -City)
      City="$2"
	  ;;
    -State)
      State="$2"
	  ;;
    -Province)
      Province="$2"
	  ;;
    -ZipCode)
      ZipCode="$2"
	  ;;
    -PostalCode)
      PostalCode="$2"
	  ;;
    -ListUsersPostOffice)
     # When using -Action "ListUsers" this is the context that will be used to find the users
     # Example: -ListUsersPostOffice "po1"
	ListUsersPostOffice="$2"
	USER_POST_OFFICE_SET="1"
	LIST_USERS_POST_OFFICE_SET="1"
	USER_ACTION="0"
	  ;;
    "")
      EMPTY_STRING_SENT=1
	  ;;
    '')
      EMPTY_STRING_SENT=1
	  ;;
    *)

	if [ $UserIdListPassed -eq 0 ]
	then
		if [ $SWITCH -eq 0 ]
		then
      		printf "***************************\n"
      		printf "* Error: Invalid argument *\n"
      		printf "***************************\n"
      		echo "$2"
      		exit 1
		fi
	else
		BULK_USER_ACTION=1
	fi
	;;
  esac
  shift
  shift
done

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"







function GET_GROUP_DOMAIN()
{

GROUP_POST_OFFICE_IN_LOWER=`echo "${OffBoardUserGroupPostOffice}" | tr [A-Z] [a-z]`

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"
TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/list/USER"
{
RESPONSE=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}`
} 1>> /dev/null 2>> /dev/null
echo "$RESPONSE" 1> ${TEMP_FILE_ONE} 

cat ${TEMP_FILE_ONE}  | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' 1> ${TEMP_FILE_TWO}

GROUP_DOMAIN=`grep "id:USER." ${TEMP_FILE_TWO} | grep -i ".${GROUP_POST_OFFICE_IN_LOWER}." | head -1 | awk -F id:USER. '{printf $2}' | awk -F . '{printf $1}'`

GROUP_DOMAIN=`echo "${GROUP_DOMAIN}" | tr [A-Z] [a-z]`

rm ${TEMP_FILE_ONE}

rm ${TEMP_FILE_TWO}

}





function ADD_USER_TO_OFFBOARD_GROUP()
{

GROUP_IN_ORIGINAL="${OffBoardUserGroupName}"

GROUP_IN_PROCESSED=`echo ${GROUP_IN} | grep -c "\%20"`

if [ $GROUP_IN_PROCESSED -eq 0 ]
then
	GROUP_IN_USABLE=`echo "${OffBoardUserGroupName}" |sed 's/ /%20/g'`
fi

#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

USER_SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"

GROUP_SEARCHURL="$BASEURL/list/group.csv?name=${GROUP_IN_USABLE}&postoffice=${OffBoardUserGroupPostOffice}&attrs=domain,postoffice,name"

{
USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${USER_SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`  
} 1>> /dev/null 2>> /dev/null

{
GROUP_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${GROUP_SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/groups/"$3""}'`  
} 1>> /dev/null 2>> /dev/null

USER_DOMAIN=`echo "${USER_URL}" | awk -F /domains/ '{printf $2}' | awk -F /postoffices '{printf $1}'`

USER_POST_OFFICE_URL=`echo ${USER_URL} | awk -F /postoffices/ '{printf $2}' | awk -F /users '{printf $1}'`

GROUP_POST_OFFICE_URL=`echo ${GROUP_URL} | awk -F /postoffices/ '{printf $2}' | awk -F /groups '{printf $1}' | tr [A-Z] [a-z]`

GROUP_BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/domains/${GROUP_DOMAIN}/postoffices/${GROUP_POST_OFFICE_URL}/groups/${GROUP_IN_USABLE}/members"

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

declare GROUP_UPDATE_DATA='{"id":"GROUP.'$USER_DOMAIN'.'$USER_POST_OFFICE_URL'.'$UserId'","participation":"BLIND_COPY"}'

{
curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${GROUP_BASEURL} -H "Content-Type: application/json" -X POST -d ${GROUP_UPDATE_DATA}
} 1>> /dev/null 2>> /dev/null


declare -i EXIT_STATUS=`echo $?`

rm ${TEMP_FILE_ONE} 2> /dev/null

return 0

if [ $EXIT_STATUS -eq 0 ]
then
echo ""
echo "Added ${UserId} To Group: ${GROUP_IN_ORIGINAL}"
else
echo ""
echo "${UserId} NOT Added To Group: ${GROUP_IN_ORIGINAL}"
echo ""
fi



}




function CONFIRM_GROUP_EXISTENCE()
{

GET_GROUP_DOMAIN
TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

GROUP_IN_ORIGINAL="${OffBoardUserGroupName}"

GROUP_IN_PROCESSED=`echo "${OffBoardUserGroupName}" | grep -c "\%20"`

if [ $GROUP_IN_PROCESSED -eq 0 ]
then
GROUP_IN_USABLE=`echo "${OffBoardUserGroupName}" | sed 's/ /%20/g'`
fi


GROUP_POST_OFFICE_IN_LOWER=`echo "${GROUP_IN_USABLE}" | tr [A-Z] [a-z]`

GROUP_POST_OFFICE_IN_LOWER=`echo "${OffBoardUserGroupPostOffice}" | tr [A-Z] [a-z]`

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="domains/${GROUP_DOMAIN}/postoffices/${GROUP_POST_OFFICE_IN_LOWER}/groups/${GROUP_IN_USABLE}"

# echo "curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H \"Content-Type: application/json\""
{
RESPONSE=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`
} 1> /dev/null 2> /dev/null

echo "$RESPONSE" 1> ${TEMP_FILE_ONE} 

cat ${TEMP_FILE_ONE}  | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' 1> ${TEMP_FILE_TWO}

GROUP_GET_WORKED=`grep -ic "postOfficeName" ${TEMP_FILE_ONE}`

rm ${TEMP_FILE_ONE}

rm ${TEMP_FILE_TWO}

if [ $GROUP_GET_WORKED -eq 0 ]
then
	return 1
fi

ADD_USER_TO_OFFBOARD_GROUP

}

function UserReport()
{

if [ $SKIP_USER_REPORT -gt 0 ]
then
	return
else
	SKIP_USER_REPORT=1
fi

#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"
{
URL=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3"/mailboxstats"}'`

TEST=`curl -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`

declare -i EXIT_STATUS=`echo $?`

} 1> /dev/null 2> /dev/null


if [ $EXIT_STATUS -ne 0 ]
then
	echo "Cannot Get Information on User $UserId"
	return 0
fi


{
USER_URL=`curl  -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
} 1>> /dev/null 2>> /dev/null

{
USER_OBJECT=`curl  -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`
} 1>> /dev/null 2>> /dev/null

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

TEMP_FILE_THREE="${TEMP_FILE_DIRECTORY}/$$.3.tmp"

echo "$USER_OBJECT" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

FID=`echo "${USER_OBJECT}" | grep -Po '"fileId":"\K[^"]*'`

LAST_NAME=`echo "${USER_OBJECT}" | grep -Po '"surname":"\K[^"]*'`

FIRST_NAME=`echo "${USER_OBJECT}" | grep -Po '"givenName":"\K[^"]*'`

USERID_IN_UPPER=`echo "${UserId}" | tr [a-z] [A-Z]`

declare -i LDAP_DIRECTORY_SPECIFIED=`echo "${USER_OBJECT}" | grep -c "directoryId"`

if [ $LDAP_DIRECTORY_SPECIFIED -gt 0 ]
then
LDAP_ID_INFO=`echo "${USER_OBJECT}" | grep -Po '"ldapDn":"\K[^"]*'`
fi

declare -i SHOW_GENERATIONAL_QUALIFIER=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "GenerationQualifier"`

declare -i SHOW_MIDDLE_INITIAL=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "MiddleInitial"`

MIDDLE_INITIAL=""
declare -i MIDDLE_INITIAL_EXISTS=0

if [ $SHOW_MIDDLE_INITIAL -gt 0 ]
then
	MIDDLE_INITIAL_EXISTS=`echo "${USER_OBJECT}" | grep -c "middleInitial"` 
fi

if [ $MIDDLE_INITIAL_EXISTS -gt 0 ]
then
	MIDDLE_INITIAL=`echo "${USER_OBJECT}" | grep -Po '"middleInitial":"\K[^"]*'`
fi

GENERATIONAL_QUALIFIER=""
declare -i GENERATIONAL_QUALIFIER_EXISTS=0 

if [ $SHOW_GENERATIONAL_QUALIFIER -gt 0 ]
then
	GENERATIONAL_QUALIFIER_EXISTS=`echo "${USER_OBJECT}" | grep -c "suffix"` 
fi

if [ $GENERATIONAL_QUALIFIER_EXISTS -gt 0 ]
then
	GENERATIONAL_QUALIFIER=`echo "${USER_OBJECT}" | grep -Po '"suffix":"\K[^"]*'`
fi


echo "" 1>> ${TEMP_FILE_THREE}
echo "USERID: ${USERID_IN_UPPER}" 1>> ${TEMP_FILE_THREE}
if [ $MIDDLE_INITIAL_EXISTS -gt 0 ]
then
	echo "Name:   ${FIRST_NAME} ${MIDDLE_INITIAL} ${LAST_NAME} ${GENERATIONAL_QUALIFIER}" 1>> ${TEMP_FILE_THREE}
else
	echo "Name:   ${FIRST_NAME} ${LAST_NAME} ${GENERATIONAL_QUALIFIER}" 1>> ${TEMP_FILE_THREE}
fi

if [ $SHOW_ADMIN_LEVEL_USER_INFO -gt 0 ]
then
	echo "" 1>> ${TEMP_FILE_THREE}
	echo "File ID (FID):  ${FID}" 1>> ${TEMP_FILE_THREE}
	if [ $LDAP_DIRECTORY_SPECIFIED -gt 0 ]
	then
		echo "NETWORK ID:  ${LDAP_ID_INFO}" 1>> ${TEMP_FILE_THREE}
	fi
	echo "" 1>> ${TEMP_FILE_THREE}
fi


if [ $SHOW_USER_ATTRIBUTE_DISPLAY -eq 0 ]
then

	function WACK(){
	printf '\u2714' 1>> ${TEMP_FILE_THREE}
	echo " Enabled" 1>> ${TEMP_FILE_THREE}
	printf '\u2718' 1>> ${TEMP_FILE_THREE}
	echo " Disabled" 1>> ${TEMP_FILE_THREE}
	}

	cat ${TEMP_FILE_THREE}
	rm ${TEMP_FILE_ONE} ${TEMP_FILE_TWO} ${TEMP_FILE_THREE} 1> /dev/null 2> /dev/null
	return
fi

	declare -i SHOW_OFFICE_PHONE=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "OfficePhone"`
	declare -i OFFICE_PHONE_EXISTS=0

	if [ $SHOW_OFFICE_PHONE -gt 0 ]
	then
		OFFICE_PHONE_EXISTS=`echo "${USER_OBJECT}" | grep -c "telephoneNumber"` 
	fi

declare -i SHOW_DESCRIPTION=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "Description"`
declare -i DESCRIPTION_EXISTS=0

if [ $SHOW_DESCRIPTION -gt 0 ]
then
	DESCRIPTION_EXISTS=`echo "${USER_OBJECT}" | grep -c "description"` 
fi

if [ $DESCRIPTION_EXISTS -gt 0 ]
then
	DESCRIPTION=`echo "${USER_OBJECT}" | grep -Po '"description":"\K[^"]*'`
	echo "Description: ${DESCRIPTION}" 1>> ${TEMP_FILE_THREE}
fi

if [ $OFFICE_PHONE_EXISTS -gt 0 ]
then
	OFFICE_PHONE_NUMBER=`echo "${USER_OBJECT}" | grep -Po '"telephoneNumber":"\K[^"]*'`
	echo "Office Phone: ${OFFICE_PHONE_NUMBER}" 1>> ${TEMP_FILE_THREE}
fi


declare -i SHOW_MOBILE_PHONE=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "MobilePhone"`
declare -i MOBILE_PHONE_EXISTS=0

if [ $SHOW_MOBILE_PHONE -gt 0 ]
then
	MOBILE_PHONE_EXISTS=`echo "${USER_OBJECT}" | grep -c "mobilePhoneNumber"` 
fi

if [ $MOBILE_PHONE_EXISTS -gt 0 ]
then
	MOBILE_PHONE_NUMBER=`echo "${USER_OBJECT}" | grep -Po '"mobilePhoneNumber":"\K[^"]*'`
	echo "Mobile Phone: ${MOBILE_PHONE_NUMBER}" 1>> ${TEMP_FILE_THREE}
fi

declare -i SHOW_HOME_PHONE=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "HomePhone"`
declare -i HOME_PHONE_EXISTS=0

if [ $SHOW_HOME_PHONE -gt 0 ]
then
	HOME_PHONE_EXISTS=`echo "${USER_OBJECT}" | grep -c "homePhoneNumber"` 
fi

if [ $HOME_PHONE_EXISTS -gt 0 ]
then
	HOME_PHONE_NUMBER=`echo "${USER_OBJECT}" | grep -Po '"homePhoneNumber":"\K[^"]*'`
	echo "Home Phone: ${HOME_PHONE_NUMBER}" 1>> ${TEMP_FILE_THREE}
fi

declare -i SHOW_OTHER_PHONE=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "OtherPhone"`
declare -i OTHER_PHONE_EXISTS=0

if [ $SHOW_OTHER_PHONE -gt 0 ]
then
	OTHER_PHONE_EXISTS=`echo "${USER_OBJECT}" | grep -c "otherPhoneNumber"` 
fi

if [ $OTHER_PHONE_EXISTS -gt 0 ]
then
	OTHER_PHONE_NUMBER=`echo "${USER_OBJECT}" | grep -Po '"otherPhoneNumber":"\K[^"]*'`
	echo "Other Phone: ${OTHER_PHONE_NUMBER}" 1>> ${TEMP_FILE_THREE}
fi



declare -i SHOW_FAX_NUMBER=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "FaxNumber"`
declare -i FAX_NUMBER_EXISTS=0

if [ $SHOW_FAX_NUMBER -gt 0 ]
then
	FAX_NUMBER_EXISTS=`echo "${USER_OBJECT}" | grep -c "faxNumber"` 
fi

if [ $FAX_NUMBER_EXISTS -gt 0 ]
then
	FAX_NUMBER=`echo "${USER_OBJECT}" | grep -Po '"faxNumber":"\K[^"]*'`
	echo "Fax Number: ${FAX_NUMBER}" 1>> ${TEMP_FILE_THREE}
fi

declare -i SHOW_PAGER_NUMBER=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "PagerNumber"`
declare -i PAGER_NUMBER_EXISTS=0

if [ $SHOW_PAGER_NUMBER -gt 0 ]
then
	PAGER_NUMBER_EXISTS=`echo "${USER_OBJECT}" | grep -c "pagerNumber"` 
fi

if [ $PAGER_NUMBER_EXISTS -gt 0 ]
then
	PAGER_NUMBER=`echo "${USER_OBJECT}" | grep -Po '"pagerNumber":"\K[^"]*'`
	echo "Pager Number: ${PAGER_NUMBER}" 1>> ${TEMP_FILE_THREE}
fi

declare -i SHOW_TITLE=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "Title"`
declare -i TITLE_EXISTS=0

if [ $SHOW_TITLE -gt 0 ]
then
	TITLE_EXISTS=`echo "${USER_OBJECT}" | grep -c "title"` 
fi

if [ $TITLE_EXISTS -gt 0 ]
then
	TITLE=`echo "${USER_OBJECT}" | grep -Po '"title":"\K[^"]*'`
	echo "Title: ${TITLE}" 1>> ${TEMP_FILE_THREE}
fi

declare -i SHOW_COMPANY=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "Company"`
declare -i COMPANY_EXISTS=0

if [ $SHOW_COMPANY -gt 0 ]
then
	COMPANY_EXISTS=`echo "${USER_OBJECT}" | grep -c "company"` 
fi

if [ $COMPANY_EXISTS -gt 0 ]
then
	COMPANY=`echo "${USER_OBJECT}" | grep -Po '"company":"\K[^"]*'`
	echo "Company: ${COMPANY}" 1>> ${TEMP_FILE_THREE}
fi


declare -i SHOW_DEPARTMENT=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "Department"`
declare -i DEPARTMENT_EXISTS=0

if [ $SHOW_DEPARTMENT -gt 0 ]
then
	DEPARTMENT_EXISTS=`echo "${USER_OBJECT}" | grep -c "department"` 
fi

if [ $DEPARTMENT_EXISTS -gt 0 ]
then
	DEPARTMENT=`echo "${USER_OBJECT}" | grep -Po '"department":"\K[^"]*'`
	echo "Department: ${DEPARTMENT}" 1>> ${TEMP_FILE_THREE}
fi

declare -i SHOW_LOCATION=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "Location"`
declare -i LOCATION_EXISTS=0

if [ $SHOW_LOCATION -gt 0 ]
then
	LOCATION_EXISTS=`echo "${USER_OBJECT}" | grep -c "location"` 
fi

if [ $LOCATION_EXISTS -gt 0 ]
then
	LOCATION=`echo "${USER_OBJECT}" | grep -Po '"location":"\K[^"]*'`
	echo "Location: ${LOCATION}" 1>> ${TEMP_FILE_THREE}
fi


declare -i SHOW_STREET=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "Street"`
declare -i STREET_EXISTS=0

if [ $SHOW_STREET -gt 0 ]
then
	STREET_EXISTS=`echo "${USER_OBJECT}" | grep -c "streetAddress"` 
fi

if [ $STREET_EXISTS -gt 0 ]
then
	STREET=`echo "${USER_OBJECT}" | grep -Po '"streetAddress":"\K[^"]*'`
	echo "Street: ${STREET}" 1>> ${TEMP_FILE_THREE}
fi

declare -i SHOW_POBOX=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "POBox"`
declare -i POBOX_EXISTS=0

if [ $SHOW_POBOX -gt 0 ]
then
	POBOX_EXISTS=`echo "${USER_OBJECT}" | grep -c "postOfficeBox"` 
fi

if [ $POBOX_EXISTS -gt 0 ]
then
	POBOX=`echo "${USER_OBJECT}" | grep -Po '"postOfficeBox":"\K[^"]*'`
	echo "PO Box: ${POBOX}" 1>> ${TEMP_FILE_THREE}
fi

declare -i SHOW_CITY=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "City"`
declare -i CITY_EXISTS=0

if [ $SHOW_CITY -gt 0 ]
then
	CITY_EXISTS=`echo "${USER_OBJECT}" | grep -c "city"` 
fi

if [ $CITY_EXISTS -gt 0 ]
then
	CITY=`echo "${USER_OBJECT}" | grep -Po '"city":"\K[^"]*'`
	echo "City: ${CITY}" 1>> ${TEMP_FILE_THREE}
fi

declare -i SHOW_STATE=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "State"`
declare -i STATE_EXISTS=0

if [ $SHOW_STATE -gt 0 ]
then
	STATE_EXISTS=`echo "${USER_OBJECT}" | grep -c "stateProvince"` 
fi

if [ $STATE_EXISTS -gt 0 ]
then
	STATE=`echo "${USER_OBJECT}" | grep -Po '"stateProvince":"\K[^"]*'`
	echo "State: ${STATE}" 1>> ${TEMP_FILE_THREE}
fi

declare -i SHOW_PROVINCE=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "Province"`
declare -i PROVINCE_EXISTS=0

if [ $SHOW_PROVINCE -gt 0 ]
then
	PROVINCE_EXISTS=`echo "${USER_OBJECT}" | grep -c "stateProvince"` 
fi

if [ $PROVINCE_EXISTS -gt 0 ]
then
	PROVINCE=`echo "${USER_OBJECT}" | grep -Po '"stateProvince":"\K[^"]*'`
	echo "Province: ${PROVINCE}" 1>> ${TEMP_FILE_THREE}
fi

declare -i SHOW_ZIPCODE=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "ZipCode"`
declare -i ZIPCODE_EXISTS=0

if [ $SHOW_ZIPCODE -gt 0 ]
then
	ZIPCODE_EXISTS=`echo "${USER_OBJECT}" | grep -c "postalZipCode"` 
fi

if [ $ZIPCODE_EXISTS -gt 0 ]
then
	ZIPCODE=`echo "${USER_OBJECT}" | grep -Po '"postalZipCode":"\K[^"]*'`
	echo "ZipCode: ${ZIPCODE}" 1>> ${TEMP_FILE_THREE}
fi

declare -i SHOW_POSTALCODE=`echo "${SHOW_USER_ATTRIBUTE_DISPLAY_LIST}" | grep -ic "PostalCode"`
declare -i POSTALCODE_EXISTS=0

if [ $SHOW_POSTALCODE -gt 0 ]
then
	POSTALCODE_EXISTS=`echo "${USER_OBJECT}" | grep -c "postalZipCode"` 
fi

if [ $POSTALCODE_EXISTS -gt 0 ]
then
	POSTALCODE=`echo "${USER_OBJECT}" | grep -Po '"postalZipCode":"\K[^"]*'`
	echo "Postal Code: ${POSTALCODE}" 1>> ${TEMP_FILE_THREE}
fi

echo "" 1>> ${TEMP_FILE_THREE}
cat ${TEMP_FILE_THREE}
rm ${TEMP_FILE_THREE}


{
URL=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3"/mailboxstats"}'`

RESULT=`curl -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}` 1> /dev/null
} 1>> /dev/null 2>> /dev/null


if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
then
# SHOW ACCOUNT STATUS INFO - BEGIN

OBJECT_VISIBLITY=`echo "${USER_OBJECT}" | grep -Po '"visibility":"\K[^"]*'`

ACCOUNT_DISABLED_STATUS=`echo "${USER_OBJECT}" | grep -Po '"loginDisabled":"\K[^,]*'`

declare -i ACCOUNT_DISABLED_EXISTS=`echo "${USER_OBJECT}" | grep -c "loginDisabled"`

declare -i ACCOUNT_INACTIVE_EXISTS=`echo "${USER_OBJECT}" | grep -c "forceInactive"`

declare -i ACCOUNT_EXPIRATION_EXISTS=`echo "${USER_OBJECT}" | grep -c "expirationDate"`

declare -i MAILBOX_IS_EXPIRED=0

if [ $ACCOUNT_EXPIRATION_EXISTS -eq 1 ]
then

	ACCOUNT_EXPIRATION_EPOCH=`grep "expirationDate" ${TEMP_FILE_TWO} | awk -F : '{printf $2}'`

	declare -i ACCOUNT_EXIPIRE_EPOCH_TIME="$ACCOUNT_EXPIRATION_EPOCH"

	declare -i CURRENT_EPOCH_TIME=`date +%s%N | cut -b1-13`

	if [ $CURRENT_EPOCH_TIME -gt $ACCOUNT_EXIPIRE_EPOCH_TIME ]
	then
		MAILBOX_IS_EXPIRED=1
	fi

	ACCOUNT_EXPIRATION_EPOCH=${ACCOUNT_EXPIRATION_EPOCH::-3}

	ACCOUNT_EXPIRATION_DATE_OF_EXPIRATION=`date -d@${ACCOUNT_EXPIRATION_EPOCH} | awk -F ":00" '{printf $1}'`

	declare -i HOUR_MARK=`date -d @${ACCOUNT_EXPIRATION_EPOCH} | grep -c ":00:00"`

	if [ $HOUR_MARK -gt 0 ]
	then
		ACCOUNT_EXPIRATION_DATE_OF_EXPIRATION="${ACCOUNT_EXPIRATION_DATE_OF_EXPIRATION}:00"
	fi

		ACCOUNT_EXPIRATION_YEAR_OF_EXPIRATION=`date -d@${ACCOUNT_EXPIRATION_EPOCH} | awk '{printf $NF}'`

fi

THE_DATE_EPOCH_EXISTS=`echo "${RESULT}" | grep -c "lastClientLoginTime"`


THE_DATE_EPOCH=`echo "${RESULT}" | awk -F "\"lastClientLoginTime\":" '{printf $2}' | awk -F "," '{print $1}'`

if [ $THE_DATE_EPOCH_EXISTS -gt 0 ]
then
	if [ $THE_DATE_EPOCH -lt 2 ]
	then

		LAST_LOG_DATE="This user has never logged in"
		printf '\u2714'
		echo " Last Login Time:  ${LAST_LOG_DATE}"
	else

		if [ $THE_DATE_EPOCH_EXISTS -eq 1 ]
		then
		THE_DATE_EPOCH=`echo "${RESULT}" | awk -F "\"lastClientLoginTime\":" '{printf $2}' | awk -F "," '{print $1}'`
		LAST_LOG_DATE=`date -d@${THE_DATE_EPOCH}`
			printf '\u2714'
			echo " Last Login Time:  ${LAST_LOG_DATE}"
		else
			LAST_LOG_DATE="This user has never logged in"
			printf '\u2718'
			echo " Last Login Time:  ${LAST_LOG_DATE}"
		fi

	fi

fi

if [ $ACCOUNT_INACTIVE_EXISTS -gt 0 ]
then

ACCOUNT_DISABLED_STATUS=`echo ${USER_OBJECT} | awk -F "\"forceInactive\":" '{printf $2}' | awk -F "," '{print $1}'`

	if [ ${ACCOUNT_DISABLED_STATUS} = 'true' ]
	then
		printf '\u2718'
		echo " Account Active:  No"
	else
		printf '\u2714'
		echo " Account Active:  Yes"
	fi
else
	printf '\u2714'
	echo " Account Active:  Yes"
fi

if [ $ACCOUNT_DISABLED_EXISTS -gt 0 ]
then

ACCOUNT_DISABLED_STATUS=`echo ${USER_OBJECT} | awk -F "\"loginDisabled\":" '{printf $2}' | awk -F "," '{print $1}'`

	if [ ${ACCOUNT_DISABLED_STATUS} = 'true' ]
	then
		printf '\u2718'
		echo " Account Enabled:  No"
	else
		printf '\u2714'
		echo " Account Enabled:  Yes"
	fi
else
	printf '\u2714'
	echo " Account Enabled:  Yes"
fi












	case ${OBJECT_VISIBLITY} in
	NONE)
		printf '\u2718'
		echo " User Visibility:  Not Visible"
	;;
	POST_OFFICE)
		printf '\u2714'
		echo " User Visibility:  Post Office"
	;;
	DOMAIN)
		printf '\u2714'
		echo " User Visibility:  Domain"
	;;
	SYSTEM)
		printf '\u2714'
		echo " User Visibility:  System"
	;;
	esac


	if [ $ACCOUNT_EXPIRATION_EXISTS -eq 1 ]
	then
		if [ $MAILBOX_IS_EXPIRED -eq 0 ]
		then
			printf '\u2714'
			echo " Account Expiration Date:  ${ACCOUNT_EXPIRATION_DATE_OF_EXPIRATION} ${ACCOUNT_EXPIRATION_YEAR_OF_EXPIRATION}"
		else
			printf '\u2718'
			echo " Account Expiration Date:  ${ACCOUNT_EXPIRATION_DATE_OF_EXPIRATION} ${ACCOUNT_EXPIRATION_YEAR_OF_EXPIRATION} (Account Expired)"

		fi
	fi

# SHOW ACCOUNT STATUS INFO - END
fi

if [ $SHOW_MAILBOX_STATS -gt 0 ]
then
# SHOW MAILBOX STATS BEGIN
echo ""

MAILBOX_SIZE_IN_MB=`echo "${RESULT}" | awk -F "\"mailboxCurrSizeMB\":" '{printf $2}' | awk -F "," '{print $1}'`

TOTAL_UNREAD_ITEMS=`echo "${RESULT}" | awk -F "\"totalUnreadCount\":" '{printf $2}' | awk -F "," '{print $1}' | sed 's/\}//g'`

MAILBOX_SIZE_LIMIT=`echo "${RESULT}" | awk -F "\"mailboxSizeLimit\":" '{printf $2}' | awk -F "," '{print $1}'`

if [ ${MAILBOX_SIZE_LIMIT} = -1 ]
then
MAILBOX_SIZE_LIMIT="No Size Limit Currently Configured"
else
	declare -i MB=${MAILBOX_SIZE_LIMIT}

	if [ $MB -eq 1 ]
	then
	MAILBOX_SIZE_LIMIT="1 Megabyte"
	else
	MAILBOX_SIZE_LIMIT="$MB Megabytes"
	fi
	

fi

if [ $MAILBOX_SIZE_IN_MB = -1 ]
then
MAILBOX_SIZE_IN_MB="0"
fi



echo "Mailbox Size:  ${MAILBOX_SIZE_IN_MB} Megabytes"
echo "Mailbox Size Limit:  ${MAILBOX_SIZE_LIMIT} Megabytes"
echo "Unread Items:  $TOTAL_UNREAD_ITEMS"

# SHOW MAILBOX STATS END
fi





rm ${TEMP_FILE_ONE} 2> /dev/null

rm ${TEMP_FILE_TWO} 2> /dev/null

rm ${TEMP_FILE_THREE} 2> /dev/null
 



}





if [ $USER_POST_OFFICE_SET -eq 0 ]
then
	if [ $DEFAULT_USER_POST_OFFICE_SET -gt 0 ]
	then
		declare -i DEFAULT_USER_POST_OFFICE_SET_LENGTH=`echo "${DefaultUserSearchPostOffice}" | wc -c`
			if [ $DEFAULT_USER_POST_OFFICE_SET_LENGTH -gt 5 ]
			then
				PostOffice="${DefaultUserSearchPostOffice}"
			fi
	fi
fi


function ReportError()
{
echo ""
echo "Error: $1"
echo ""
exit 1
}

function OutputMessage()
{
echo "$1"
}


### Discover or establish a settings_gw.cfg file ###
function ProcessSettingsFile()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then
echo "GW_ADMIN_SERVICE_ADDRESS=\"172.0.0.0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then
	GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"
fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
	echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}
fi

}


function CHECK_GWADMIN_SERVICE()
{

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

if [ $DEBUG -eq 0 ]
then
	{
	CURL_TRY=`curl   -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`
	} 1>> /dev/null 2>> /dev/null
else

	CURL_TRY=`curl   -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`
fi

AUTHENTICATION_WORKED=`echo $?`

if [ ${AUTHENTICATION_WORKED} -ne 0 ]
then
echo ""
echo "Error authenticating to GroupWise Admnistration Service"
echo ""
exit 1
fi

}


function CheckUserAgainstExcludeGroup()
{
THE_USER_IN=$1
SILENT_MODE=$2


if [ $IGNORE_EXCLUDE_GROUP -gt 0 ]
then
	return 0
fi



if [ $EXCLUDE_GROUP_TEMP_FILE_DEFINED -eq 0 ]
then

	if [ $EXCLUDE_GROUP_OFF -eq 1 ]
	then
		return 0
	fi



	declare -i GW_EXCLUDE_GROUP_ENABLED=0

	source ${GW_SCRIPT_SETTINGS_FILE}

	if [ $GW_EXCLUDE_GROUP_ENABLED -eq 0 ]
	then
		return 0
	fi

	if [ ${GW_EXCLUDE_GROUP_NAME} == 'exclude_group_name_here' ]
	then
		echo ""
		echo "Error: Please properly configure exclude group name"
		echo ""
		exit 1
	fi

	if [ ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} == 'exclude_group_post_office_name_here' ]
	then
		echo ""
		echo "Error: Please properly configure exclude group's post office name"
		echo ""
		exit 1
	fi

	if [ ${GW_EXCLUDE_GROUP_DOMAIN_NAME} == 'exclude_group_domain_name_here' ]
	then
		echo ""
		echo "Error: Please properly configure exclude group's domain name"
		echo ""
		exit 1
	fi


BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="domains/${GW_EXCLUDE_GROUP_DOMAIN_NAME}/postoffices/${GW_EXCLUDE_GROUP_POST_OFFICE_NAME}/groups/${GW_EXCLUDE_GROUP_NAME}/members"

{
GROUP_GET_OBJECT=`curl   -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`
} 1> /dev/null 2> /dev/null
GROUP_GET_WORKED=`echo $?`

	if [ ${GROUP_GET_WORKED} -ne 0 ]
	then
		echo ""
		echo "Error getting exclude group information"
		echo ""
		exit 1
	fi

	declare -i GROUP_GET_OBJECT_HAS_COUNTER=`echo "${GROUP_GET_OBJECT}" | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -c "resultInfo:outOf:"`

	if [ $GROUP_GET_OBJECT_HAS_COUNTER -ne 1 ]
	then
		echo ""
		echo "Error getting exclude group membership count[1]"
		echo ""
		exit 1
	fi

	declare -i GROUP_GET_OBJECT_COUNTER=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep "resultInfo:outOf:" | awk -F ':' '{printf $3}'`

	declare -i NUMBER_OF_USERS_IN_GROUP=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -ce "^name:"`

	if ! [[ "${GROUP_GET_OBJECT_COUNTER}" =~ ^[0-9]+$ ]]
	then
		echo ""
		echo "Error getting exclude group membership count [2]"
		echo ""
		exit 1
	fi

	if ! [[ "${NUMBER_OF_USERS_IN_GROUP}" =~ ^[0-9]+$ ]]
	then
		echo ""
		echo "Error getting exclude group membership count [3]"
		echo ""
		exit 1
	fi

	if [ ${GROUP_GET_OBJECT_COUNTER} -ne ${NUMBER_OF_USERS_IN_GROUP} ]
	then
		echo ""
		echo "Error getting exclude group membership count [4]"
		echo ""
		exit 1
	fi

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -e "^name:"  | sed 's/name://' | tr [A-Z] [a-z] 1> ${TEMP_FILE_ONE}
EXCLUDE_GROUP_TEMP_FILE="$TEMP_FILE_ONE"
EXCLUDE_GROUP_TEMP_FILE_DEFINED=1
fi

THE_USER_IN_LOWERCASE=`echo "${THE_USER_IN}" | tr [A-Z] [a-z]`


declare -i USER_EXISTS_IN_EXCLUDE_GROUP=`grep -c "$THE_USER_IN_LOWERCASE" ${EXCLUDE_GROUP_TEMP_FILE}`


if [ $USER_EXISTS_IN_EXCLUDE_GROUP -eq 0 ]
then
	return 0
else

	if [ $SILENT_MODE -eq 1 ]
	then

		if [[ ${USERID_IN_LOWER} == ${THE_USER_IN_LOWERCASE} ]]
		then
			echo ""
			echo "ERROR: Insufficient rights to administer user: ${THE_USER_IN}"
			echo ""
			rm ${EXCLUDE_GROUP_TEMP_FILE} 2> /dev/null
			exit 1
		fi

	else 
		return 1
	fi

fi

}


function VERIFY_USER_EXISTENCE()
{

source ${GW_SCRIPT_SETTINGS_FILE}

SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"

{
USER_URL=`curl   -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
} 1> /dev/null 2> /dev/null

{
USER_OBJECT=`curl   -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -ne 0 ]
then
	echo ""
	echo "Error: Userid: ${UserId} Does not Exist in Post Office: ${PostOffice}"
	echo ""
	exit 1
fi

CheckUserAgainstExcludeGroup "${UserId}" "1"

}


ProcessSettingsFile
CHECK_GWADMIN_SERVICE

if [ $USERID_SET -gt 0 ] && [ $POST_OFFICE_SET -gt 0 ]
then
	VERIFY_USER_EXISTENCE
fi

if [[ -n "$Action" ]];
then

	if [ $Action == "UserReport" ]
	then
		UserReport
		exit 0
	fi
fi


function SHOW_HELP()
{
echo ""
echo "--- Script Help ---"
echo ""
echo "Modify a GroupWise User"
echo ""
echo "Script usage:     $0 [options]"
echo ""
echo "Example:          $0 -Action \"ModifyUser\" -UserId \"bsmith\" -FirstName \"Bob\" -LastName \"Smith\" -PostOffice \"po1.domain1\" -UserPassword \"ChangeM3N0W\""
echo ""
echo "Help:             $0 -h"
echo ""
}

if [ $SHOW_HELP_MESSAGE -gt 0 ]
then
	SHOW_HELP
	exit 0
fi



function CallSleep()
{
# If the script is running in a terminal, the fact that a sleep/pause is happening will show.
TEST_TTY=`tty | sed -e "s/.*tty\(.*\)/\1/"`

declare -i TEST_HAS_DEV=`echo "$TEST_TTY" | grep -c "/dev"`

if [ $TEST_HAS_DEV -gt 0 ]
then
	if [ $SleepTime -eq 1 ]
	then
	OutputMessage "Pausing for $SleepTime Second"
	else
	OutputMessage "Pausing for $SleepTime Seconds"
	fi
fi
sleep $SleepTime
}





function REPORT_USERS()
{

TEMP_FILE_ONE=$1

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.22.tmp"


grep -v "postoffice,name,givenName,surname" $TEMP_FILE_ONE 1> $TEMP_FILE_TWO 


# Add an additional line to the file

while read CURRENT_LINE
do
declare -i SKIP_USER=0

POST_OFFICE=`echo "${CURRENT_LINE}" | awk -F , '{printf $1}' | tr [A-Z] [a-z]`

USER_NAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $2}'`

# See if the user is in the Exclude Group
# --------------------------------
CheckUserAgainstExcludeGroup "${USER_NAME}" "0"
SKIP_USER=`echo $?`

if [ $SKIP_USER -gt 0 ]
then
	# Skip the user
	continue
fi
# --------------------------------

FIRST_NAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $3}'`

LAST_NAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $4}'`

if [ ${POST_OFFICE} == ${POST_OFFICE_IN_LOWER} ]
then

echo "${USER_NAME} - ${FIRST_NAME} ${LAST_NAME}"


fi

done < ${TEMP_FILE_TWO}

rm $TEMP_FILE_ONE 2> /dev/null

rm $TEMP_FILE_TWO 2> /dev/null

echo ""

}

function REPORT_OFFBOARD_USERS()
{

TEMP_FILE_ONE=$1

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.22.tmp"


grep -v "postoffice,name,givenName,surname,adminDefined20" $TEMP_FILE_ONE 1> $TEMP_FILE_TWO 


# Add an additional line to the file

while read CURRENT_LINE
do
declare -i SKIP_USER=0

POST_OFFICE=`echo "${CURRENT_LINE}" | awk -F , '{printf $1}' | tr [A-Z] [a-z]`

USER_NAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $2}'`

# See if the user is in the Exclude Group
# --------------------------------
CheckUserAgainstExcludeGroup "${USER_NAME}" "0"
SKIP_USER=`echo $?`

if [ $SKIP_USER -gt 0 ]
then
	# Skip the user
	continue
fi
# --------------------------------

CIMITRA_OFFBOARD_INDICATOR=`echo "${CURRENT_LINE}" | awk -F , '{printf $5}'`

declare -i OFFBOARD_EXISTS=`echo "${CIMITRA_OFFBOARD_INDICATOR}" | grep -c "CIMITRA_OFFBOARD"`

if [ $OFFBOARD_EXISTS -eq 0 ]
then
	# Skip the user`	
	continue
fi

FIRST_NAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $3}'`

LAST_NAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $4}'`

if [ ${POST_OFFICE} == ${POST_OFFICE_IN_LOWER} ]
then

echo "${USER_NAME} - ${FIRST_NAME} ${LAST_NAME}"


fi

done < ${TEMP_FILE_TWO}

rm $TEMP_FILE_ONE 2> /dev/null

rm $TEMP_FILE_TWO 2> /dev/null

echo ""

}


function REMOVE_ACCOUNT_EXPIRE()
{

#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

DATA='{"expirationDate":"0"}'

SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"

{
URL=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
} 1>> /dev/null 2>> /dev/null
# --- Now use curl to change the value

{
curl -f ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data $DATA 
} 1>> /dev/null 2>> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
	printf '\u2714'
	echo " Expiration for Account: ${UserId} Removed"
	echo ""
else
	echo ""
	printf '\u2718'
	echo " Expiraton For Account: ${UserId} Not Removed"
	echo ""
fi
}

function CHANGE_VISIBILITY_TO_NONE()
{


#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

# --- Create json data for the setting change

DATA="{\"visibility\":\"NONE\"}"


SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"


{
URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data $DATA
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
	printf '\u2714'
	echo " Visibility for Account: ${UserId} | Set To: Not Visible"
else
	echo ""
	printf '\u2718'
	echo " Visibility for Account: ${UserId} NOT Changed"
	echo ""
fi

}

function CHANGE_VISIBILITY_TO_POST_OFFICE()
{


#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

# --- Create json data for the setting change

DATA="{\"visibility\":\"POST_OFFICE\"}"


SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"


{
URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data $DATA
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
	printf '\u2714'
	echo " Visibility for Account: ${UserId} | Set To: Post Office"
else
	echo ""
	printf '\u2718'
	echo " Visibility for Account: ${UserId} NOT Changed"
	echo ""
fi

}

function CHANGE_VISIBILITY()
{

re='^[1-4]+$'

if ! [[ $UserVisibility =~ $re ]]
then
   echo "Error: Wrong Value Entered"
   exit 1
fi

case $UserVisibility in
1)
VISIBILITY="NONE"
VISIBILITY_TEXT="No Visbility"
;;
2)
VISIBILITY="POST_OFFICE"
VISIBILITY_TEXT="Post Office"
;;
3)
VISIBILITY="DOMAIN"
VISIBILITY_TEXT="Domain"
;;
4)
VISIBILITY="SYSTEM"
VISIBILITY_TEXT="System"
;;
*)
echo "Error: Wrong Value Entered"
exit 1
;;
esac


#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

# --- Create json data for the setting change

DATA="{\"visibility\":\"${VISIBILITY}\"}"


SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"


{
URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data $DATA
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
echo ""
	printf '\u2714'
echo " Visibility for Account: ${UserId} | Set to: ${VISIBILITY_TEXT}"
echo ""
else
echo ""
	printf '\u2718'
echo " Visibility for Account: ${UserId} NOT Changed"
echo ""
fi

}


function RESET_PASSWORD()
{

declare -i USERID_IN_LOWER=`echo "${UserId}" | tr [A-Z] [a-z]`

if [ $USERID_IN_LOWER == "admin" ]
then
echo ""
echo "Will Not Change GroupWise Password For: ${UserId}"
echo ""
return
fi

#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

# --- Create json data for the new password
DATA="{\"userPassword\":{\"value\":\"${NEW_PASSWORD_IN}\"}}"

# --- Build url to search for the user. the /list/user.csv will return the user data in csv format.
# --- attrs returns only the users domain,po of the USERID_IN, so we can build the url to change the password

SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"

# --- Use curl to search the admin service for the user,and gawk to build the proper user url

{
URL=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3"/clientoptions"}'`
} 1>> /dev/null 2>> /dev/null

# --- Now use curl to change the password

{
curl -f -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data $DATA
} 1>> /dev/null 2>> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
	echo ""
	printf '\u2714'
	echo " GroupWise Password Changed For: ${UserId}"
	echo ""
else
	echo ""
	printf '\u2718'
	echo " GroupWise Password NOT Changed For: ${UserId}"
	echo ""
fi
}


function SET_ACCOUNT_EXPIRE()
{

#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

# --- Create json data for the setting change

DATA='{"expirationDate":"'$ExpirationDate'000"}'

SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"

{
URL=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
} 1>> /dev/null 2> /dev/null
# --- Now use curl to change the value

{
curl -f -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data $DATA 
} 1>> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
declare -i HOUR_MARK=`date -d @${ExpirationDate} | grep -c ":00:00"`
THE_DATE=`date -d @${ExpirationDate} | awk -F ":00:00" '{printf $1}'`
THE_YEAR=`date -d @${ExpirationDate} | awk '{printf $NF}'`
echo ""
	if [ $HOUR_MARK -eq 0 ]
	then
     		printf '\u2714'
		echo " Expiration for Account: ${UserId} Set To: ${THE_DATE} ${THE_YEAR}"
	else
     		printf '\u2714'
		echo " Expiration for Account: ${UserId} Set To: ${THE_DATE}:00 ${THE_YEAR}"
	fi
	echo ""
else
	echo ""
	printf '\u2718'
	echo " Expiration For Account: ${UserId} Not Set!"
	echo ""
fi
}


function LIST_USERS_IN_POST_OFFICE()
{
#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/list/user.csv?attrs=postoffice,name,givenName,surname"

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

{
curl --silent -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${BASEURL} -o ${TEMP_FILE_TWO}
} 1> /dev/null 2> ${TEMP_FILE_ONE}

declare -i EXIT_STATUS=`wc -m  ${TEMP_FILE_ONE} | awk '{printf $1}'`

if [ $EXIT_STATUS -ne 0 ]
then
echo ""
echo "Cannot List Users"
echo ""
exit 1
fi

rm ${TEMP_FILE_ONE} 2> /dev/null


echo "All Users in Post Office: ${POST_OFFICE_IN_UPPER}"
echo ""


REPORT_USERS ${TEMP_FILE_TWO}


}

function LIST_OFFBOARD_USERS_IN_POST_OFFICE()
{
#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/list/user.csv?attrs=postoffice,name,givenName,surname,adminDefined20"

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

{
curl --silent -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${BASEURL} -o ${TEMP_FILE_TWO}
} 1> /dev/null 2> ${TEMP_FILE_ONE}

declare -i EXIT_STATUS=`wc -m  ${TEMP_FILE_ONE} | awk '{printf $1}'`

if [ $EXIT_STATUS -ne 0 ]
then
echo ""
echo "Cannot List Users"
echo ""
exit 1
fi

rm ${TEMP_FILE_ONE} 2> /dev/null


echo "All Offboarded Users in Post Office: ${POST_OFFICE_IN_UPPER}"
echo ""


REPORT_OFFBOARD_USERS ${TEMP_FILE_TWO}


}



function PROCESS_EDIR_SETTINGS()
{

GW_ADMIN_USER='admin_level_user'
declare -i GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT=0
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
	echo ""
	echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
	echo ""
	exit 1
fi


if [[ ${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT} -eq 0 ]]
then
	echo "GW_EDIR_ADMIN_USER=\"cn=admin,o=cimitra\"" >> ${GW_SCRIPT_SETTINGS_FILE}
	echo "GW_EDIR_ADMIN_PASSWORD=\"eDirLetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
	echo "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS=\"172.0.0.1\"" >> ${GW_SCRIPT_SETTINGS_FILE}
	echo "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT=\"389\"" >> ${GW_SCRIPT_SETTINGS_FILE}
fi

}

function GET_GROUPWISE_EDIR_USER_OBJECT()
{

#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"
{
URL=`curl   -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3"/mailboxstats"}'`

TEST=`curl   -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -ne 0 ]
then
	echo ""
	echo "Error: Cannot establish connection to GroupWise Admin Service"
	echo ""	
	exit 1
fi

{
USER_URL=`curl   -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
} 1>> /dev/null 2>> /dev/null

{
USER_OBJECT=`curl   -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`
} 1>> /dev/null 2>> /dev/null

declare -i USER_HAS_LDAP_TREE=`echo "${USER_OBJECT}" | grep -c "directoryId"`


if [ $USER_HAS_LDAP_TREE -eq 0 ]
then
	echo ""
	echo "Error: Cannot discover eDirectory tree for GroupWise account ${UserId}"
	echo ""
	exit 1
fi

declare -i CN_EXISTS=`echo "${USER_OBJECT}" | grep -cPo '"ldapDn":"\K[^"]*'`

if [ $CN_EXISTS -eq 1 ]
then
	FULL_NETWORK_ID=`echo "${USER_OBJECT}" | grep -Po '"ldapDn":"\K[^"]*'`
else
	declare -i USER_HAS_NETWORK_ID=`echo "${USER_OBJECT}" | grep -c "networkId"`

	if [ $USER_HAS_NETWORK_ID -eq 1 ]
	then
		NETWORK_ID_ONE=`echo "${USER_OBJECT}" | grep -Po '"networkId":"\K[^"]*'`
		NETWORK_ID_TWO=`echo "${NETWORK_ID_ONE}" | sed -r 's/(.*)\./\1,o=/'`
		NETWORK_ID_THREE=`echo "${NETWORK_ID_TWO}" | sed 's/\./,ou=/g'`
		FULL_NETWORK_ID="cn=${NETWORK_ID_THREE}"
	else
		echo ""
		echo "Error: Cannot discover network ID for GroupWise account ${UserId}"
		echo ""	
		exit 1
	fi

fi

}

function SYNC_GROUPWISE_USER_OBJECT()
{

#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"
{
URL=`curl   -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3"/mailboxstats"}'`

TEST=`curl   -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -ne 0 ]
then
	echo ""
	echo "Error: Cannot establish connection to GroupWise Admin Service"
	echo ""
	exit 1
fi

{
USER_URL=`curl   -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
} 1> /dev/null 2> /dev/null

{
USER_OBJECT=`curl   -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`
} 1> /dev/null 2> /dev/null

USER_DOMAIN=`echo "${USER_OBJECT}" | grep -Po '"domainName":"\K[^"]*'`

SYNC_URL="$BASEURL/domains/${USER_DOMAIN}/postoffices/${PostOffice}/users/${UserId}/directorylink/sync"

{
DO_SYNC=`curl   -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X POST ${SYNC_URL}` 1> /dev/null
} 1> /dev/null 2> /dev/null

}


function CHANGE_USER_EDIR_ATTRIBUTE()
{

LDAP_OBJECT_NAME="$1"
INPUT_IN="$2"
INPUT_TYPE_TEXT="$3"
# --- Create ldif data for the setting change

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp.ldif"

echo "dn: ${FULL_NETWORK_ID}" 1> ${TEMP_FILE_ONE}
echo "changetype: Modify" 1>> ${TEMP_FILE_ONE}
echo "replace: ${LDAP_OBJECT_NAME}" 1>> ${TEMP_FILE_ONE}
echo "${LDAP_OBJECT_NAME}: ${INPUT_IN}" 1>> ${TEMP_FILE_ONE}

source ${GW_SCRIPT_SETTINGS_FILE}
# --- Now use ldapmodify to change the value

{
ldapmodify -x -h ${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS} -p ${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT} -w $GW_EDIR_ADMIN_PASSWORD -D $GW_EDIR_ADMIN_USER -f ${TEMP_FILE_ONE}
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

rm ${TEMP_FILE_ONE} 1> /dev/null 2> /dev/null


if [ $EXIT_STATUS -eq 0 ]
then

	printf '\u2714' 
	echo " Changed ${INPUT_TYPE_TEXT} To: ${INPUT_IN}"
else
	echo ""
	printf '\u2718' 
	echo " ${INPUT_TYPE_TEXT} NOT Changed to: ${INPUT_IN}"
	echo ""
fi
}



function CHECK_FOR_LDAP_DIRECTORY()
{

if [ $SKIP_LDAP_ASSOCIATION_CHECK -eq 1 ]
then
	return
fi

source ${GW_SCRIPT_SETTINGS_FILE}

SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"

{
USER_URL=`curl   -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
} 1>> /dev/null  2>> /dev/null

{
USER_OBJECT=`curl   -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`
} 1>> /dev/null  2>> /dev/null

declare -i LDAP_DIRECTORY_SPECIFIED=`echo ${USER_OBJECT} | grep -c "directoryId"`

if [ $LDAP_DIRECTORY_SPECIFIED -gt 0 ]
then

	PROCESS_EDIR_SETTINGS
	GET_GROUPWISE_EDIR_USER_OBJECT
	SKIP_GROUPWISE_USER_OBJECT_CHANGE=1

fi

}



function ShowUserReport()
{
if [ $DisableUserReport -eq 1 ]
then
	return 0
fi

if [ $USER_ACTION -eq 0 ]
then
	if [ $GROUP_ACTION -eq 0 ]
	then
		return 0
	fi
fi

UserReport
}



function ACCOUNT_ENABLE()
{
#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

# --- Create json data for the setting change

DATA="{\"loginDisabled\":\"false\"}"

SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"

{
URL=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
} 1>> /dev/null 2>> /dev/null
# --- Now use curl to change the value

{
curl -f -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data $DATA
} 1>> /dev/null 2>> /dev/null


declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
	printf '\u2714'
echo " Account Enabled: ${UserId} "
else
echo ""
	printf '\u2718'
echo " Account NOT Enabled: ${UserId} "
echo ""
fi
}


function ACCOUNT_ACTIVE()
{
#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

# --- Create json data for the setting change

DATA="{\"forceInactive\":\"false\"}"

SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"

{
URL=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
} 1>> /dev/null 2>> /dev/null
# --- Now use curl to change the value

{
curl -f -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data $DATA
} 1>> /dev/null 2>> /dev/null


declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
       printf '\u2714'
	echo " Account Activated: ${UserId} "
else
	echo ""
	printf '\u2718'
	echo " Account NOT Activated: ${UserId} "
	echo ""
fi
}

function ACCOUNT_INACTIVE()
{
#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

# --- Create json data for the setting change

DATA="{\"forceInactive\":\"true\"}"

SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"

{
URL=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
} 1>> /dev/null 2>> /dev/null
# --- Now use curl to change the value

{
curl -f -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data $DATA
} 1>> /dev/null 2>> /dev/null


declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
	printf '\u2714'
	echo " Account Inactivated: ${UserId} "

else
	echo ""
	printf '\u2718'
	echo " Account NOT Inactivated: ${UserId} "
	echo ""
fi
}

function ACCOUNT_DISABLE()
{
#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

# --- Create json data for the setting change

DATA="{\"loginDisabled\":\"true\"}"

SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"

{
URL=`curl  -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
} 1>> /dev/null 2>> /dev/null
# --- Now use curl to change the value

{
curl -f -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data $DATA 
} 1>> /dev/null 2>> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then

printf '\u2714'
echo " Account Disabled: ${UserId}"

else
echo ""
printf '\u2718'
echo " Account NOT Disabled: ${UserId}"
echo ""
fi
}



### Primary Function for User GroupWise Object Change ###
function CHANGE_USER_GROUPWISE_ATTRIBUTE()
{
USERID_IN="$1"
GROUPWISE_OBJECT_NAME="$2"
LDAP_OBJECT_NAME="$3"
GROUPWISE_OBJECT_VALUE="$4"
LABEL_NAME="$5"

if [ $CHANGE_USER_INITIALIZED -eq 0 ]
then
	echo "MODIFY USER: $USERID_IN"
	echo ""
	CHANGE_USER_INITIALIZED="1"

fi


if [ $SKIP_GROUPWISE_USER_OBJECT_CHANGE -eq 1 ]
then
	CHANGE_USER_EDIR_ATTRIBUTE "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE"  "$LABEL_NAME"
	# SYNC_GROUPWISE_USER_OBJECT

	return
fi

#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

# --- Create json data for the setting change

DATA="{\"${GROUPWISE_OBJECT_NAME}\":\"${GROUPWISE_OBJECT_VALUE}\"}"

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${PostOffice}&attrs=domain,postoffice,name"

{
URL=`curl   -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
} 1> /dev/null 2> /dev/null
# --- Now use curl to change the value

{
curl   -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data "$DATA"
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then

	printf '\u2714' 
echo " Changed ${LABEL_NAME} To: ${GROUPWISE_OBJECT_VALUE}"

else
echo ""
	printf '\u2718' 
echo " ${LABEL_NAME} NOT Changed To: ${GROUPWISE_OBJECT_VALUE}"
echo ""
fi


}


function ValidateParameter()
{
Parameter="$1"
ParameterLabel="$2"

[[ -z "$Parameter" ]] && ReportError "Enter a $ParameterLabel"

}

function REVERSE_USER_OFF_BOARD()
{
ACCOUNT_ENABLE
ACCOUNT_ACTIVE
CHANGE_VISIBILITY_TO_POST_OFFICE

if [ $DISABLE_OFFBOARD_USER_TRACKING -eq 0 ]
then

	#-- Build the base url for admin service
	BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

	# --- Create json data for the setting change

	DATA="{\"adminDefined20\":\"\"}"

	SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"

	{
	URL=`curl   -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
	} 1> /dev/null 2> /dev/null

	# --- Now use curl to change the value

	{
	curl   -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data "$DATA"
	} 1> /dev/null 2> /dev/null


fi

UserReport


}

function USER_OFF_BOARD()
{
ACCOUNT_DISABLE
ACCOUNT_INACTIVE
CHANGE_VISIBILITY_TO_NONE

if [ $DISABLE_OFFBOARD_USER_TRACKING -eq 0 ]
then

	#-- Build the base url for admin service
	BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

	# --- Create json data for the setting change

	DATA="{\"adminDefined20\":\"CIMITRA_OFFBOARD\"}"

	SEARCHURL="$BASEURL/list/user.csv?name=${UserId}&postoffice=${PostOffice}&attrs=domain,postoffice,name"

	{
	URL=`curl   -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`
	} 1> /dev/null 2> /dev/null

	# --- Now use curl to change the value

	{
	curl   -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data "$DATA"
	} 1> /dev/null 2> /dev/null


fi

printf '\u2714'
echo " Offboard Complete For User: ${UserId}"

UserReport

if [ $ADD_OFFBOARD_USER_TO_GROUP -gt 0 ]
then

	CONFIRM_GROUP_EXISTENCE
fi
}

function ModifyUser()
{

ValidateParameter "$UserId" "Userid | Example: -UserId \"bsmith\""
ValidateParameter "$PostOffice" "Post Office| Example: -PostOffice \"po1\""


theFirstNameUniversal="${FirstName}"
theLastNameUniversal="${LastName}"

CHECK_FOR_LDAP_DIRECTORY



		if [ $BULK_USER_ACTION -eq 1 ]
		then
			if [ $FIRST_USER_MODIFIED -eq 0 ]
			then
				OutputMessage "-----------------------"
				FIRST_USER_MODIFIED="1"
			fi
		OutputMessage "Modifying User: $UserId"
		USER_REPORT_ALREADY_RAN="1"
		fi

if [[ -n "$UserPassword" ]];
then
	RESET_PASSWORD
fi

if [ $Action == "ExpireUser" ]
then

	if [[ -n "$ExpirationDate" ]];
	then
		SET_ACCOUNT_EXPIRE
		if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
		then
			UserReport
		fi
	fi
fi

if [ $Action == "RemoveExpiration" ]
then
	REMOVE_ACCOUNT_EXPIRE

	if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
	then
		UserReport
	fi
fi

if [[ -n "$RemoveExpiration" ]];
then
	REMOVE_ACCOUNT_EXPIRE

	if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
	then
		UserReport
	fi
	
fi

if [[ -n "$EnableUser" ]];
then
	ACCOUNT_ENABLE

	if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
	then
		UserReport
	fi
	
fi

if [[ -n "$DisableUser" ]];
then
	ACCOUNT_DISABLE

	if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
	then
		UserReport
	fi

	exit 0
fi

if [[ -n "$UserActivate" ]];
then
	ACCOUNT_ACTIVE

	if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
	then
		UserReport
	fi

fi

if [[ -n "$UserDeactivate" ]];
then
	ACCOUNT_INACTIVE

	if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
	then
		UserReport
	fi
fi

if [ $Action == "ChangeUserVisibility" ]
then

	if [[ -n "$UserVisibility" ]];
	then
		CHANGE_VISIBILITY

		if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
		then
			UserReport
		fi
	fi

fi




if [[ -n "$OfficePhone" ]];
then

	declare GROUPWISE_OBJECT_NAME="telephoneNumber"
	declare LDAP_OBJECT_NAME="telephoneNumber"
	declare GROUPWISE_OBJECT_VALUE="$OfficePhone"
	declare LABEL_NAME="Office Phone"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"

fi

if [[ -n "$OtherPhone" ]];
then

	declare GROUPWISE_OBJECT_NAME="otherPhoneNumber"
	declare LDAP_OBJECT_NAME="otherTelephone"
	declare GROUPWISE_OBJECT_VALUE="$OtherPhone"
	declare LABEL_NAME="Other Phone"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"

fi



if [[ -n "$MobilePhone" ]];
then

	declare GROUPWISE_OBJECT_NAME="mobilePhoneNumber"
	declare LDAP_OBJECT_NAME="mobile"
	declare GROUPWISE_OBJECT_VALUE="$MobilePhone"
	declare LABEL_NAME="Mobile Phone"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"



fi

if [[ -n "$FaxNumber" ]];
then
	
	declare GROUPWISE_OBJECT_NAME="faxNumber"
	declare LDAP_OBJECT_NAME="facsimileTelephoneNumber"
	declare GROUPWISE_OBJECT_VALUE="$FaxNumber"
	declare LABEL_NAME="Fax Number"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"


fi

if [[ -n "$PagerNumber" ]];
then
	
	declare GROUPWISE_OBJECT_NAME="pagerNumber"
	declare LDAP_OBJECT_NAME="pager"
	declare GROUPWISE_OBJECT_VALUE="$PagerNumber"
	declare LABEL_NAME="Pager Number"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"


fi

if [[ -n "$NewFirstName" ]];
then

	declare GROUPWISE_OBJECT_NAME="givenName"
	declare LDAP_OBJECT_NAME="givenName"
	declare GROUPWISE_OBJECT_VALUE="$NewFirstName"
	declare LABEL_NAME="First Name"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"

fi


if [[ -n "$NewLastName" ]];
then

	declare GROUPWISE_OBJECT_NAME="surname"
	declare LDAP_OBJECT_NAME="sn"
	declare GROUPWISE_OBJECT_VALUE="$NewLastName"
	declare LABEL_NAME="Last Name"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"

fi

if [[ -n "$GenerationQualifier" ]];
then

	declare GROUPWISE_OBJECT_NAME="suffix"
	declare LDAP_OBJECT_NAME="generationQualifier"
	declare GROUPWISE_OBJECT_VALUE="$GenerationQualifier"
	declare LABEL_NAME="Generational Qualifier"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"

	fi

if [[ -n "$MiddleInitial" ]];
then

	declare GROUPWISE_OBJECT_NAME="middleInitial"
	declare LDAP_OBJECT_NAME="initials"
	declare GROUPWISE_OBJECT_VALUE="$MiddleInitial"
	declare LABEL_NAME="Middle Initial"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"

fi

if [[ -n "$Title" ]];
then

	declare GROUPWISE_OBJECT_NAME="title"
	declare LDAP_OBJECT_NAME="title"
	declare GROUPWISE_OBJECT_VALUE="$Title"
	declare LABEL_NAME="Title"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"


fi

if [[ -n "$Company" ]];
then

	declare GROUPWISE_OBJECT_NAME="company"
	declare LDAP_OBJECT_NAME="Company"
	declare GROUPWISE_OBJECT_VALUE="$Company"
	declare LABEL_NAME="Company"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"


fi

if [[ -n "$Department" ]];
then

	declare GROUPWISE_OBJECT_NAME="department"
	declare LDAP_OBJECT_NAME="ou"
	declare GROUPWISE_OBJECT_VALUE="$Department"
	declare LABEL_NAME="Department"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"


fi

if [[ -n "$Description" ]];
then

	declare GROUPWISE_OBJECT_NAME="description"
	declare LDAP_OBJECT_NAME="description"
	declare GROUPWISE_OBJECT_VALUE="$Description"
	declare LABEL_NAME="Description"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"

fi

if [[ -n "$Location" ]];
then

	declare GROUPWISE_OBJECT_NAME="location"
	declare LDAP_OBJECT_NAME="l"
	declare GROUPWISE_OBJECT_VALUE="$Location"
	declare LABEL_NAME="Location"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"


fi

if [[ -n "$Street" ]];
then

	declare GROUPWISE_OBJECT_NAME="streetAddress"
	declare LDAP_OBJECT_NAME="street"
	declare GROUPWISE_OBJECT_VALUE="$Street"
	declare LABEL_NAME="Street"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"


fi


if [[ -n "$POBox" ]];
then

	declare GROUPWISE_OBJECT_NAME="postOfficeBox"
	declare LDAP_OBJECT_NAME="postOfficeBox"
	declare GROUPWISE_OBJECT_VALUE="$POBox"
	declare LABEL_NAME="Post Office Box"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"


fi

if [[ -n "$City" ]];
then

	declare GROUPWISE_OBJECT_NAME="city"
	declare LDAP_OBJECT_NAME="physicalDeliveryOfficeName"
	declare GROUPWISE_OBJECT_VALUE="$City"
	declare LABEL_NAME="City"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"


fi


if [[ -n "$State" ]];
then

	declare GROUPWISE_OBJECT_NAME="stateProvince"
	declare LDAP_OBJECT_NAME="st"
	declare GROUPWISE_OBJECT_VALUE="$State"
	declare LABEL_NAME="State"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"


fi

if [[ -n "$Province" ]];
then

	declare GROUPWISE_OBJECT_NAME="stateProvince"
	declare LDAP_OBJECT_NAME="st"
	declare GROUPWISE_OBJECT_VALUE="$Province"
	declare LABEL_NAME="Province"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"


fi


if [[ -n "$ZipCode" ]];
then

	declare GROUPWISE_OBJECT_NAME="postalZipCode"
	declare LDAP_OBJECT_NAME="postalCode"
	declare GROUPWISE_OBJECT_VALUE="$ZipCode"
	declare LABEL_NAME="ZIP Code"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"


fi

if [[ -n "$PostalCode" ]];
then

	declare GROUPWISE_OBJECT_NAME="postalZipCode"
	declare LDAP_OBJECT_NAME="postalCode"
	declare GROUPWISE_OBJECT_VALUE="$PostalCode"
	declare LABEL_NAME="Postal Code"

	CHANGE_USER_GROUPWISE_ATTRIBUTE "$UserId" "$GROUPWISE_OBJECT_NAME" "$LDAP_OBJECT_NAME" "$GROUPWISE_OBJECT_VALUE" "$LABEL_NAME"


fi

# Call User Report
UserReport
}



if [[ -z "$Action" ]] ;then
	if [ $QUIET_MODE -eq 1 ]
	then
		exit 0
	fi
	OutputMessage "Use The -Action Parameter"
	OutputMessage ""
	OutputMessage "Reports"
	OutputMessage ""
	OutputMessage "Example: $0 -Action \"ListAllUsersInTree\""
OutputMessage "Example: $0 -Action \"ListUsers\""
OutputMessage ""
OutputMessage "User Object Reports/Actions"
OutputMessage ""
OutputMessage "Example: $0 -Action \"SearchForUser\""
OutputMessage "Example: $0 -Action \"UserReport\""
OutputMessage "Example: $0 -Action \"CreateUser\""
OutputMessage "Example: $0 -Action \"ModifyUser\""
OutputMessage "Example: $0 -Action \"MoveUser\""
OutputMessage ""
OutputMessage "User Object Account Access"
OutputMessage ""
OutputMessage "Example: $0 -Action \"DisableUser\""
OutputMessage "Example: $0 -Action \"EnableUser\""
OutputMessage "Example: $0 -Action \"LockUser\""
OutputMessage "Example: $0 -Action \"UnlockUser\""
OutputMessage "Example: $0 -Action \"SetUserExpiration\""
OutputMessage "Example: $0 -Action \"RemoveUserExpiration\""
OutputMessage ""
OutputMessage "User and Group Object Changes"
OutputMessage ""
OutputMessage "Example: $0 -Action \"GroupReport\""
OutputMessage "Example: $0 -Action \"CreateGroup\""
OutputMessage "Example: $0 -Action \"AddUserToGroup\""
OutputMessage "Example: $0 -Action \"RemoveUserFromGroup\""

OutputMessage ""
ReportError "An -Action is required"
fi


function RemoveExcludeGroupListTempFile()
{

if [ $EXCLUDE_GROUP_TEMP_FILE_DEFINED -gt 0 ]
then
	rm $EXCLUDE_GROUP_TEMP_FILE 2> /dev/null
fi

}


if [ $Action == "ListUsersInPostOffice" ]
then
	LIST_USERS_IN_POST_OFFICE
	RemoveExcludeGroupListTempFile
	exit 0

fi

if [ $Action == "ListOffBoardUsers" ]
then
	LIST_OFFBOARD_USERS_IN_POST_OFFICE
	RemoveExcludeGroupListTempFile
	exit 0
	
fi

if [ $Action == "ModifyUser" ]
then
	ModifyUser
	SYNC_GROUPWISE_USER_OBJECT
	exit 0
fi

if [ $Action == "OffBoardUser" ]
then
	USER_OFF_BOARD

	if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
	then
		UserReport
	fi

	exit 0
fi

if [ $Action == "ReverseOffBoardUser" ]
then
	REVERSE_USER_OFF_BOARD

	if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
	then
		UserReport
	fi

	exit 0
fi

if [ $Action == "ChangeUserVisibility" ]
then

	if [[ -n "$UserVisibility" ]];
	then
		CHANGE_VISIBILITY

		if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
		then
			UserReport
		fi

	fi
	exit 0

fi

if [ $Action == "ExpireUser" ]
then

	if [[ -n "$ExpirationDate" ]];
	then
		SET_ACCOUNT_EXPIRE

		if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
		then
			UserReport
		fi

	fi
	exit 0

fi

if [ $Action ==  "RemoveExpiration" ];
then
	REMOVE_ACCOUNT_EXPIRE

	if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
	then
		UserReport
	fi
	exit 0
fi

if [ $Action ==  "DisableUser" ];
then
	ACCOUNT_DISABLE

	if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
	then
		UserReport
	fi
	exit 0
fi


if [ $Action ==  "EnableUser" ];
then
	ACCOUNT_ENABLE

	if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
	then
		UserReport
	fi
	exit 0
fi

if [ $Action ==  "UserDeactivate" ];
then
	ACCOUNT_INACTIVE

	if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
	then
		UserReport
	fi
	exit 0
fi

if [ $Action ==  "UserActivate" ];
then
	ACCOUNT_ACTIVE

	if [ $SHOW_ACCOUNT_STATUS -gt 0 ]
	then
		UserReport
	fi
	exit 0
fi

if [ $Action ==  "ChangeUserPassword" ];
then
	if [[ -n "$UserPassword" ]];
	then
		RESET_PASSWORD
	fi
fi