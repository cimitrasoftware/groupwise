#!/bin/bash

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"

INTEGRATE_SCRIPT="integrate.sh"

declare -i INTEGRATE_SCRIPT_EXISTS=`test -f ${SCRIPT_PATH}/${INTEGRATE_SCRIPT} ; echo $?`

if [ $INTEGRATE_SCRIPT_EXISTS -ne 0 ]
then
echo ""
echo "Error: The Script ${SCRIPT_PATH}/${INTEGRATE_SCRIPT} Does Not Exist"
echo ""
exit 1
fi

POST_OFFICE_IN=$1

PO_IN=`echo ${POST_OFFICE_IN// /}`

if [ -z "$PO_IN" ]
then
echo ""
echo "Error:   Specify the Post Office Name to Integrate"
echo "" 
echo "Example: $0 po1"
echo ""
exit 1
fi

PO_IN=`echo "${PO_IN}" | tr [A-Z] [a-z]`

echo ""
echo "Creating Cimitra Integration With Post Office: ${PO_IN}"
echo ""
echo ""
echo "Creating Cimitra Integration With Post Office: ${PO_IN}"
echo ""
echo "NOTE: This may take a few minutes . . . "
echo ""

cd ${SCRIPT_PATH}

test -d ${PO_IN}

declare -i POST_OFFICE_DIR_EXISTS=`echo $?`

if [ $POST_OFFICE_DIR_EXISTS -eq 0 ]
then

GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/${PO_IN}/settings_gw.cfg"

test -f ${GW_SCRIPT_SETTINGS_FILE}

declare -i SETTINGS_FILE_EXISTS=`echo $?`

	if [ $SETTINGS_FILE_EXISTS -eq 0 ]
	then

	test -f ${SCRIPT_PATH}/${PO_IN}/${INTEGRATE_SCRIPT}

	declare -i INTEGRATE_SCRIPT_EXISTS=`echo $?`

		if [ $INTEGRATE_SCRIPT_EXISTS -eq 0 ]
		then
		echo ""
		echo "Using Specially Created Directory: ${SCRIPT_PATH}/${PO_IN}"
		echo ""
		cd ${SCRIPT_PATH}/${PO_IN}
		fi

	fi


fi


/bin/bash ./${INTEGRATE_SCRIPT} -p ${PO_IN} 1> /dev/null 2> /dev/null & 1> /dev/null 2> /dev/null


exit 0
