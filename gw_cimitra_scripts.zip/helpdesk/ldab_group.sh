#!/bin/bash

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"
EDIR_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_edir.cfg"

ldapsearch -x -LLL -H -h ${EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS} -p ${EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT}  -b "ou=users,o=cimitra" -s sub '(&(objectClass=inetOrgPerson)(memberof=cn=people-admins,ou=groups,dc=example,dc=com))' -D "cn=admin,dc=example,dc=com" -w admin uid
