#!/usr/bin/env bash
declare -i SHOW_HELP_MESSAGE=0
declare TEMP_FILE_DIRECTORY="/var/tmp"
while [ $# -gt 0 ]; do
  case "$1" in
    --help*|-h*)
    SHOW_HELP_MESSAGE=1
      ;;
    -UserId)
      UserId="$2"
	  ;;
    -Context)
      Context="$2"
	  ;;
    -FirstName)
      FirstName="$2"
      ;;
    -LastName)
      LastName="$2"
      ;;
    -DefaultPassword)
      DefaultPassword="$2"
	  ;;
    -Password)
      Password="$2"
	  ;;
    -Action)
      Action="$2"
	  ;;
    *)
      printf "***************************\n"
      printf "* Error: Invalid argument.*\n"
      printf "***************************\n"
      exit 1
  esac
  shift
  shift
done

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"

function ReportError()
{
echo ""
echo "Error: $1"
echo ""
exit 1
}

function OutputMessage()
{
echo "$1"
}


### Discover or establish a settings_edir.cfg file ###
function ProcessSettingsFile()
{
# See if a EDIR_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${EDIR_SCRIPT_SETTINGS_FILE}" ]] 
then
EDIR_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_edir.cfg"
fi

# Test and see if the EDIR_SCRIPT_SETTINGS_FILE file exists
declare -i EDIR_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${EDIR_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the EDIR_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $EDIR_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then
echo "EDIR_AUTH_STRING=\"SuperS3cr3t\"" >> ${EDIR_SCRIPT_SETTINGS_FILE}
echo "EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS_ONE=\"192.168.1.53\"" >> ${EDIR_SCRIPT_SETTINGS_FILE}
echo "EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT_ONE=\"389\"" >> ${EDIR_SCRIPT_SETTINGS_FILE}
echo "EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS_TWO=\"192.168.1.54\"" >> ${EDIR_SCRIPT_SETTINGS_FILE}
echo "EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT_TWO=\"389\"" >> ${EDIR_SCRIPT_SETTINGS_FILE}
echo "EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS_THREE=\"192.168.1.54\"" >> ${EDIR_SCRIPT_SETTINGS_FILE}
echo "EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT_THREE=\"389\"" >> ${EDIR_SCRIPT_SETTINGS_FILE}
echo "EDIR_USER=\"cn=admin,o=cimitra\"" >> ${EDIR_SCRIPT_SETTINGS_FILE}
echo "EDIR_EXCLUDE_GROUP=\"cn=cimitra_exclude,ou=groups,o=cimitra\"" >> ${EDIR_SCRIPT_SETTINGS_FILE}
echo ""
echo "Please configure the eDirectory Script Settings file: ${EDIR_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi

# Read the EDIR_SCRIPT_SETTINGS_FILE file
source ${EDIR_SCRIPT_SETTINGS_FILE}

timeout 1 bash -c "(echo > /dev/tcp/$EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS_ONE/$EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT_ONE) >/dev/null 2>&1"

PORT_CHECK_EXIT_CODE=`echo $?`

if [ $PORT_CHECK_EXIT_CODE -eq 0 ]
then
EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS="$EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS_ONE"
EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT="$EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT_ONE"
return
fi


timeout 1 bash -c "(echo > /dev/tcp/$EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS_TWO/$EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT_TWO) >/dev/null 2>&1"

PORT_CHECK_EXIT_CODE=`echo $?`
if [ $PORT_CHECK_EXIT_CODE -eq 0 ]
then
EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS="$EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS_TWO"
EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT="$EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT_TWO"
return
fi

timeout 1 bash -c "(echo > /dev/tcp/$EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS_THREE/$EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT_THREE) >/dev/null 2>&1"

PORT_CHECK_EXIT_CODE=`echo $?`
if [ $PORT_CHECK_EXIT_CODE -eq 0 ]
then
EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS="$EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS_THREE"
EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT="$EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT_THREE"
return
else
ReportError "Cannot Connect to eDirectory LDAP Server(s)"
fi

}

ProcessSettingsFile

function SHOW_HELP()
{
echo ""
echo "--- Script Help ---"
echo ""
echo "Create or Modify User"
echo ""
echo "Script usage:     $0 [options]"
echo ""
echo "Example:          $0 -Action \"CreateUser\" -UserId \"bsmith\" -FirstName \"Bob\" -LastName \"Smith\" -Context \"users.finance.cimitra\" -Password \"ChangeM3N0W\""
echo ""
echo "Example:          $0 -Action \"ChangePassword\" -UserId \"bsmith\" -Context \"users.finance.cimitra\" -Password \"ChangeM3N0W\""
echo ""
echo "Help:             $0 -h"
echo ""
}

if [ $SHOW_HELP_MESSAGE -gt 0 ]
then
SHOW_HELP
exit 0
fi


function ValidateParameter()
{
Parameter="$1"
ParameterLabel="$2"

[[ -z "$Parameter" ]] && ReportError "Enter a $ParameterLabel"

}

function ChangePassword()
{
[[ -z "$Context" ]] && ReportError "Enter a Context"
[[ -z "$UserId" ]] && ReportError "Enter a UserId"

if [[ -z "$Password" ]];then

	if [[ -z "$DefaultPassword" ]];then
	ValidateParameter "$Password" "Password | Example: -Password \"changeM3N0W\""
	Password="${DefaultPassword}"
	else
	ReportError "Please specify a password with the -Password parameter"
	fi
fi

echo "Resetting eDirectory Password for User Object"
echo "DISTINGUISHED NAME: cn=${UserId},${Context}"

source ${EDIR_SCRIPT_SETTINGS_FILE}

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp.ldif"

echo "dn: cn=${UserId},${Context}" 1> ${TEMP_FILE_ONE}
echo "changetype: modify" 1>> ${TEMP_FILE_ONE}
echo "replace: userPassword" 1>> ${TEMP_FILE_ONE}
echo "userPassword: ${Password}" 1>> ${TEMP_FILE_ONE}

{
ldapmodify -v -x -h ${EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS} -p ${EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT} -w ${EDIR_USER} -D ${EDIR_AUTH_STRING} -f ${TEMP_FILE_ONE}
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

rm ${TEMP_FILE_ONE} 1> /dev/null 2> /dev/null

if [ $EXIT_STATUS -eq 0 ]
then
echo ""
echo "eDirectory Account cn=${UserId},${Context} eDirectory Password Changed"
echo ""
else
echo ""
echo "eDirectory Account cn=${UserId},${Context} eDirectory Password NOT Changed"
echo ""
fi
}

function CreateUser()
{
ValidateParameter "$FirstName" "First Name | Example: -FirstName \"Bob\""
ValidateParameter "$LastName" "Last Name | Example: -LastName \"Smith\""
ValidateParameter "$Context" "Context | Example: -Context \"users.finance.cimitra\""
ValidateParameter "$UserId" "Context | Example: -UserId \"bsmith\""

if [[ -z "$Password" ]];then

	if [[ -z "$DefaultPassword" ]];then
	ValidateParameter "$Password" "Password | Example: -Password \"changeM3N0W\""
	fi

fi

echo "Creating User: $FirstName $LastName"

}


if [[ -z "$Action" ]];then
OutputMessage "Use The -Action Parameter"
OutputMessage "Example: -Action \"CreateUser\""
OutputMessage "Example: -Action \"ModifyUser\""
OutputMessage "Example: -Action \"MoveUser\""
OutputMessage "Example: -Action \"UserReport\""
ReportError "An -Action is required"
fi
$Action
