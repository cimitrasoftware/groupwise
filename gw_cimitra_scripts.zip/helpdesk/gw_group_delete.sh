#!/bin/bash
###########################################
# gw_group_delete.sh                      #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.5                            #
# Modify date: 6/22/2020                  #
###########################################
# Allows for deleting a GroupWise Group

declare -i ALL_SET=0
declare -i SHOW_HELP_SCREEN=0
declare GW_SCRIPT_EXCLUDE_FILE=""
declare CURL_OUTPUT_MODE="--silent"
TEMP_FILE_DIRECTORY="/var/tmp"

declare -i USER_HAS_DIRECTORY_ASSIGNMENT=0
declare -i ALLOW_MULTIPLE_WORD_INPUT=1
declare -i PROCESS_MULTIPLE_USERS=0
declare USERID_IN_LIST=""
declare USERID_IN=""
declare USERID_IN_LOWER=""
declare NICKNAME_IN_ORIGINAL=""
declare NICKNAME_IN=""
NICKNAME_POST_OFFICE_IN_LOWER=""
NICKNAME_POST_OFFICE_IN_UPPER=""
declare -i NICKNAME_IN_PROCESSED=0
declare -i CONFIRM_DELETE_IN=0

declare -i USERID_IN_SET=0
declare -i NICKNAME_IN_SET=0
declare -i POST_OFFICE_IN_SET=0
declare -i DOMAIN_IN_SET=0
declare -i USER_POST_OFFICE_IN_SET=0
declare -i NICKNAME_POST_OFFICE_IN_SET=0
declare -i SKIP_LIST_USER_AFTER_USER_ADD=0
declare -i PARTICIPATION_TYPE=4
declare -i EXCLUDE_GROUP_OFF=0
declare -i REPLICATION_PAUSE_TIME=30


declare DOMAIN_IN=""

while getopts "i:u:p:d:r:t:eshv" opt; do
  case ${opt} in
    u) USERID_IN="$OPTARG"
	USERID_IN_SET=1
	USERID_IN_LOWER=`echo "${USERID_IN}" | tr [A-Z] [a-z]`
      ;;
    p) USER_POST_OFFICE_IN="$OPTARG"
	USER_POST_OFFICE_IN_SET=1
	USER_POST_OFFICE_IN_LOWER=`echo "${USER_POST_OFFICE_IN}" | tr [A-Z] [a-z]`
      ;;
    d) DOMAIN_IN="$OPTARG"
	DOMAIN_IN_SET=1
      ;;
    i) INPUT_IN="$OPTARG"
	CONFIRM_DELETE_IN=1
      ;;
    r) REPLICATION_PAUSE_TIME="$OPTARG"
      ;;
    s) SKIP_LIST_USER_AFTER_USER_ADD=1
      ;;
    e) EXCLUDE_GROUP_OFF=1
      ;;
    h) SHOW_HELP_SCREEN=1
      ;;
    v) CURL_OUTPUT_MODE=""
      ;;
  esac
done

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"

USERID_IN=`echo "$@" | awk -F \-u '{printf $2}' | awk -F \-i '{printf $1}'`

USERID_IN="$(echo -e "${USERID_IN}" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"

declare -i USERID_IN_EXISTS=`echo "${USERID_IN}" | wc -m`

if [ ${USERID_IN_EXISTS} -gt 1 ]
then
USERID_IN_LOWER=`echo "${USERID_IN}" | tr [A-Z] [a-z]`
USERID_IN_SET="1"
fi


INPUT_IN=`echo "$@" | awk -F \-i '{printf $2}' | awk -F \-i '{printf $1}'`

INPUT_IN="$(echo -e "${INPUT_IN}" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"

declare -i INPUT_IN_EXISTS=`echo "${INPUT_IN}" | wc -m`

if [ ${INPUT_IN_EXISTS} -gt 1 ]
then
CONFIRM_DELETE_IN="1"
fi


### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "Delete GroupWise Group Script"
echo ""
echo "Script usage:     $0 [options]"
echo ""
echo "Example:          $0 -p <group post office> -u <GroupWise group> -i <confirm word>"
echo ""
echo "Example:          $0 -p po1 -u agroup -i <confirm word>"
echo ""
echo "Help:             $0 -h"
echo ""
}



### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then
echo "GW_ADMIN_SERVICE_ADDRESS=\"172.0.0.0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then
GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"
fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then

echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}

fi

}

function CHECK_GWADMIN_SERVICE()
{

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

CURL_TRY=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

AUTHENTICATION_WORKED=`echo $?`

if [ ${AUTHENTICATION_WORKED} -ne 0 ]
then
echo ""
echo "Error authenticating to GroupWise Admnistration Service"
echo ""
exit 1
fi

}

function GET_EXCLUDE_GROUP_MEMBERSHIP()
{

declare -i GW_EXCLUDE_GROUP_ENABLED=0

source ${GW_SCRIPT_SETTINGS_FILE}

if [ $GW_EXCLUDE_GROUP_ENABLED -eq 0 ]
then
return
fi

if [ ${GW_EXCLUDE_GROUP_NAME} == 'exclude_group_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} == 'exclude_group_post_office_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's post office name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_DOMAIN_NAME} == 'exclude_group_domain_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's domain name"
echo ""
exit 1
fi

GW_EXCLUDE_GROUP_NAME_LOWER=`echo "${GW_EXCLUDE_GROUP_NAME}" | tr [A-Z] [a-z]`

if [ "${GW_EXCLUDE_GROUP_NAME_LOWER}" = "${USERID_IN_LOWER}" ]
then

	if [ $EXCLUDE_GROUP_OFF -eq 1 ]
	then
	echo ""
	echo "ERROR: Group ${USERID_IN} Cannot Be Deleted"
	echo ""
	echo "NOTE: This is the Cimitra Integration Exclusion Group: ${USERID_IN}"
	echo ""
	else
	echo ""
	echo "ERROR: Insufficient rights to administer Group: ${USERID_IN}"
	echo ""
	fi


exit 1
fi


}



### Make sure the script is being called with the correct inputs ###
function CONFIRM_CORRECT_INPUT(){

let ALL_SET=USERID_IN_SET+USER_POST_OFFICE_IN_SET+CONFIRM_DELETE_IN

if [ $ALL_SET -ne 3 ]
then
SHOW_HELP
echo ""
echo "NOTE: Insufficient Input To Run Script"
echo ""
exit 1
fi

}


function VERIFY_GROUP_EXISTENCE()
{

GROUP_IN_ORIGINAL=${USERID_IN}

GROUP_IN=`echo "${USERID_IN}" |sed 's/ /%20/g'`

#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

GROUP_SEARCHURL="$BASEURL/list/group.csv?name=${GROUP_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"

# --- Use curl to search the admin service for the user,and gawk to build the proper user url

GROUP_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${GROUP_SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/groups/"$3""}'`  

GROUP_DOMAIN=`echo "${GROUP_URL}" | awk -F /domains/ '{printf $2}' | awk -F /postoffices '{printf $1}'`

GROUP_POST_OFFICE_URL=`echo ${GROUP_URL} | awk -F /postoffices/ '{printf $2}' | awk -F /groups '{printf $1}'`

GROUP_BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/domains/${GROUP_DOMAIN}/postoffices/${GROUP_POST_OFFICE_URL}/groups/${GROUP_IN}/members"

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

{
curl --silent -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${GROUP_BASEURL} -H "Content-Type: application/json"
} 1> /dev/null 2> ${TEMP_FILE_ONE}

declare -i EXIT_STATUS=`wc -m  ${TEMP_FILE_ONE} | awk '{printf $1}'`

rm ${TEMP_FILE_ONE} 2> /dev/null


if [ $EXIT_STATUS -ne 0 ]
then
echo ""
echo "Cannot Find Group: ${GROUP_IN_ORIGINAL}"
echo ""
exit 1
fi



}


function GET_DOMAIN()
{

if [ $DOMAIN_IN_SET -eq 1 ]
then
return
fi
TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"
TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/list/USER"

RESPONSE=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}`

echo "$RESPONSE" 1> ${TEMP_FILE_ONE} 

cat ${TEMP_FILE_ONE}  | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' 1> ${TEMP_FILE_TWO}

DOMAIN_IN=`grep "id:USER." ${TEMP_FILE_TWO} | grep -i ".${USER_POST_OFFICE_IN_LOWER}." | head -1 | awk -F id:USER. '{printf $2}' | awk -F . '{printf $1}'`

DOMAIN_IN=`echo "${DOMAIN_IN}" | tr [A-Z] [a-z]`

rm ${TEMP_FILE_ONE}

rm ${TEMP_FILE_TWO}

}

function GET_USER_FULL_NAME()
{
#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

SEARCHURL="$BASEURL/list/group.csv?name=${USERID_IN}&postoffice=${USER_POST_OFFICE_IN}&attrs=domain,postoffice,name"
{
URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/groups"}'`

TEST=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -ne 0 ]
then
return
fi

USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/groups/"$3""}'`

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

echo "$USER_OBJECT" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

NAME=`echo "${USER_OBJECT}" | grep -Po '"name":"\K[^"]*'`


echo "GROUP NAME:   ${NAME}"
echo ""

rm ${TEMP_FILE_ONE} 2> /dev/null

rm ${TEMP_FILE_TWO} 2> /dev/null
 
}


### Primary Function ###


function DELETE_GROUP()
{

TEMP_FILE_ONE=$1

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.22.tmp"

grep -wi "${USERID_IN}" $TEMP_FILE_ONE | head -1 1> $TEMP_FILE_TWO 

while read CURRENT_LINE
do

USERNAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $1}'`

USERNAME_LOWER=`echo "${USERNAME}" | tr [A-Z] [a-z]`

if [ "${USERID_IN_LOWER}" = "${USERNAME_LOWER}" ]
then

POST_OFFICE=`echo "${CURRENT_LINE}" | awk -F , '{printf $2}'`

POST_OFFICE_LOWER=`echo "${POST_OFFICE}" | tr [A-Z] [a-z]`

DOMAIN=`echo "${CURRENT_LINE}" | awk -F , '{printf $3}'`


	if [ ${USER_POST_OFFICE_IN_LOWER} = ${POST_OFFICE_LOWER} ]
	then
	echo ""
	echo "Removing Group Object"
	echo "NAME:        ${USERNAME}"
	echo "POST OFFICE: ${POST_OFFICE}"
	echo "DOMAIN:      ${DOMAIN}"
break
	fi


fi

done < ${TEMP_FILE_TWO}

rm $TEMP_FILE_ONE 2> /dev/null

rm $TEMP_FILE_TWO 2> /dev/null

PROGRAMATIC_RESOURCE_NAME=`echo "${USERNAME}" | sed 's/ /%20/g'`

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="/domains/${DOMAIN}/postoffices/${POST_OFFICE}/groups/${PROGRAMATIC_RESOURCE_NAME}"

URL="${BASEURL}${ENDPOINT}" 

{
RESPONSE=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X DELETE ${URL} -H "Content-Type: application/json"`
} 1> /dev/null 2> /dev/null


declare -i RESPONSE_HAS_ERROR=0

declare -i ERROR_CONDITION_ONE=`echo "${RESPONSE}" | grep -c "404"`

declare -i ERROR_CONDITION_TWO=`echo "${RESPONSE}" | grep -c "403"`

let RESPONSE_HAS_ERROR=ERROR_CONDITION_ONE+ERROR_CONDITION_TWO


if [ $RESPONSE_HAS_ERROR -gt 0 ]
then
echo ""
echo "Error DID NOT Delete Group Object: ${USERID_IN}"
echo ""
else
echo ""
echo "Deleted Group Object: ${USERID_IN}"
echo ""
echo "Delete Confirmed By The Word: \"${INPUT_IN}\""
echo ""
fi
}


function GET_GROUPS_IN_SYSTEM()
{
#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/list/group.csv?attrs=name,postoffice,domain"

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

{
curl --silent -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${BASEURL} -o ${TEMP_FILE_TWO}
} 1> /dev/null 2> ${TEMP_FILE_ONE}

declare -i EXIT_STATUS=`wc -m  ${TEMP_FILE_ONE} | awk '{printf $1}'`

if [ $EXIT_STATUS -ne 0 ]
then
echo ""
echo "Cannot Discover Groups"
rm ${TEMP_FILE_ONE} 2> /dev/null
echo ""
return 1
fi

rm ${TEMP_FILE_ONE} 2> /dev/null

DELETE_GROUP ${TEMP_FILE_TWO}

}

main()
{
if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi

CONFIRM_CORRECT_INPUT
PROCESS_SETTINGS_FILES
CHECK_GWADMIN_SERVICE
VERIFY_GROUP_EXISTENCE
GET_EXCLUDE_GROUP_MEMBERSHIP
GET_DOMAIN
GET_GROUPS_IN_SYSTEM
}

main




