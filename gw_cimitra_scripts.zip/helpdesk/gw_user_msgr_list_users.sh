#!/bin/bash
###########################################
# gw_user_msgr_list_users.sh              #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.4                            #
# Modify date: 1/4/2020                   #
###########################################
# Allows for a GroupWise Messenger List Messenger Users

declare -i ALL_SET=0
declare -i SHOW_HELP_SCREEN=0
declare GW_SCRIPT_EXCLUDE_FILE=""
declare CURL_OUTPUT_MODE="--silent"
declare -i MESSENGER_ONLY_USERS=0

while getopts "hvm" opt; do
  case ${opt} in
    h) SHOW_HELP_SCREEN=1
      ;;
    v) CURL_OUTPUT_MODE=""
	VERBOSE_MODE=1;
      ;;
    m) MESSENGER_ONLY_USERS=1;
      ;;
  esac
done


SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"



### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "GroupWise Messenger List Messenger Accounts"
echo ""
echo "Script usage: $0"
echo ""
echo "GroupWise Messenger List Messenger Only Accounts (no GroupWise mailbox)"
echo ""
echo "Script usage: $0 -m"
echo ""
echo "Verbose Mode: $0 -v ..."
echo ""
echo "Help:         $0 -h"
echo ""
}


### Make sure the script is being called with the correct inputs ###



### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then
echo "GW_ADMIN_SERVICE_ADDRESS=\"172.0.0.0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then
GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"
fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}
fi

}

function CHECK_GWADMIN_SERVICE()
{

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

CURL_TRY=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

AUTHENTICATION_WORKED=`echo $?`

if [ ${AUTHENTICATION_WORKED} -ne 0 ]
then
echo ""
echo "Error authenticating to GroupWise Admnistration Service"
echo ""
exit 1
fi

}

# Process exclusions file
function PROCESS_EXCLUSIONS()
{

declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo ""
echo "Error: Exclusions Check File does not exist"
echo ""
return
fi

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`

if [ -z "${USER_RECORD}" ]
then
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo ""
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
echo ""
exit 1
fi

done < ${GW_SCRIPT_EXCLUDE_FILE}

}

function GET_EXCLUDE_GROUP_MEMBERSHIP()
{
declare -i GW_EXCLUDE_GROUP_ENABLED=0

source ${GW_SCRIPT_SETTINGS_FILE}

if [ $GW_EXCLUDE_GROUP_ENABLED -eq 0 ]
then
return
fi

if [ ${GW_EXCLUDE_GROUP_NAME} == 'exclude_group_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} == 'exclude_group_post_office_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's post office name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_DOMAIN_NAME} == 'exclude_group_domain_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's domain name"
echo ""
exit 1
fi


BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="domains/${GW_EXCLUDE_GROUP_DOMAIN_NAME}/postoffices/${GW_EXCLUDE_GROUP_POST_OFFICE_NAME}/groups/${GW_EXCLUDE_GROUP_NAME}/members"

GROUP_GET_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

GROUP_GET_WORKED=`echo $?`

if [ ${GROUP_GET_WORKED} -ne 0 ]
then
echo ""
echo "Error getting exclude group information"
echo ""
exit 1
fi

declare -i GROUP_GET_OBJECT_HAS_COUNTER=`echo "${GROUP_GET_OBJECT}" | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -c "resultInfo:outOf:"`

if [ $GROUP_GET_OBJECT_HAS_COUNTER -ne 1 ]
then
echo ""
echo "Error getting exclude group membership count[1]"
echo ""
exit 1
fi

declare -i GROUP_GET_OBJECT_COUNTER=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep "resultInfo:outOf:" | awk -F ':' '{printf $3}'`

declare -i NUMBER_OF_USERS_IN_GROUP=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -ce "^name:"`

if ! [[ "${GROUP_GET_OBJECT_COUNTER}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [2]"
echo ""
exit 1
fi

if ! [[ "${NUMBER_OF_USERS_IN_GROUP}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [3]"
echo ""
exit 1
fi

if [ ${GROUP_GET_OBJECT_COUNTER} -ne ${NUMBER_OF_USERS_IN_GROUP} ]
then
echo ""
echo "Error getting exclude group membership count [4]"
echo ""
exit 1
fi

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -e "^name:"  | sed 's/name://' 1> ${TEMP_FILE_ONE}

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`

if [ -z "${USER_RECORD}" ]
then
# Skip empty lines
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo ""
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
echo ""
rm ${TEMP_FILE_ONE}
exit 1

fi

done < ${TEMP_FILE_ONE}

rm ${TEMP_FILE_ONE}

}

function GET_DOMAIN()
{

if [ $DOMAIN_IN_SET -eq 1 ]
then
return
fi
TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"
TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/list/USER"

RESPONSE=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}`

echo "$RESPONSE" 1> ${TEMP_FILE_ONE} 

cat ${TEMP_FILE_ONE}  | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' 1> ${TEMP_FILE_TWO}

DOMAIN_IN=`grep "id:USER." ${TEMP_FILE_TWO} | grep -i ".${POST_OFFICE_IN}." | head -1 | awk -F id:USER. '{printf $2}' | awk -F . '{printf $1}'`

DOMAIN_IN=`echo "${DOMAIN_IN}" | tr [A-Z] [a-z]`

rm ${TEMP_FILE_ONE}

rm ${TEMP_FILE_TWO}

}

function REPORT_USERS()
{

USERS_FILE_IN=$1

TEMP_FILE_THREE="${TEMP_FILE_DIRECTORY}/$$.33.tmp"
TEMP_FILE_FOUR="${TEMP_FILE_DIRECTORY}/$$.44.tmp"


# Add an additional line to the file

while read CURRENT_LINE
do

USER_NAME=`basename "${CURRENT_LINE}" | awk -F , '{printf $1}'`

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/messengers/MessengerService/users/${USER_NAME}"

RESPONSE=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}`

echo "$RESPONSE" 1> ${TEMP_FILE_THREE} 

cat ${TEMP_FILE_THREE}  | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' 1> ${TEMP_FILE_FOUR}

if [ $MESSENGER_ONLY_USERS -eq 1 ]
then
declare -i IS_GW_USER=`cat ${TEMP_FILE_FOUR} | grep -c "sourceGuid:"`
	if [ $IS_GW_USER -gt 0 ]
	then
	continue
	fi
fi

ACCOUNT_TYPE="Messenger Only User"

declare -i IS_GW_USER=`cat ${TEMP_FILE_FOUR} | grep -c "sourceGuid:"`
	if [ $IS_GW_USER -gt 0 ]
	then
	ACCOUNT_TYPE="GroupWise User and Messenger User"
	fi

echo ""
echo "User  Name:       ${USER_NAME}"

FIRST_NAME=`cat ${TEMP_FILE_FOUR} | grep "givenName:" | awk -F ":" '{printf $2}'`
LAST_NAME=`cat ${TEMP_FILE_FOUR} | grep "surname:" | awk -F ":" '{printf $2}'`
echo "First Name:       ${FIRST_NAME}"
echo "Last  Name:       ${LAST_NAME}"
echo "User  Type:       ${ACCOUNT_TYPE}"
MESSENGER_POLICY=`cat ${TEMP_FILE_FOUR} | grep "policyId:" | awk -F ":" '{printf $2}'`

echo "Messenger Policy: ${MESSENGER_POLICY}"

done < ${USERS_FILE_IN}

rm $USERS_FILE_IN 2> /dev/null

rm $TEMP_FILE_THREE 2> /dev/null

rm $TEMP_FILE_FOUR 2> /dev/null

echo ""

}


### Primary Function ###
function LIST_ALL_MESSENGER_ONLY_USERS()
{

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

TEMP_FILE_THREE="${TEMP_FILE_DIRECTORY}/$$.3.tmp"

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/messengers/MessengerService/users"

RESPONSE=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}`

echo "$RESPONSE" 1> ${TEMP_FILE_ONE} 

cat ${TEMP_FILE_ONE}  | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' 1> ${TEMP_FILE_TWO}

cat ${TEMP_FILE_TWO} | grep "@url:/gwadmin-service/messengers/messengerservice/users" 1> $TEMP_FILE_THREE

REPORT_USERS $TEMP_FILE_THREE

rm ${TEMP_FILE_ONE} 2> /dev/null

rm ${TEMP_FILE_TWO} 2> /dev/null

rm ${TEMP_FILE_THREE} 2> /dev/null

}



main()
{
if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi

PROCESS_SETTINGS_FILES
CHECK_GWADMIN_SERVICE
LIST_ALL_MESSENGER_ONLY_USERS
}

main



