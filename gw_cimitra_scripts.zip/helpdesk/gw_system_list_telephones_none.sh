#!/bin/bash
###########################################
# gw_system_list_telephones_none.sh       #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.4                            #
# Modify date: 2/18/2020                  #
###########################################
# Allows for listing all users without office phone numbers in a GroupWise system

declare -i SHOW_HELP_SCREEN=0
declare CURL_OUTPUT_MODE="--silent"
TEMP_FILE_DIRECTORY="/var/tmp"

declare -i GROUP_IN_SET=0
declare -i POST_OFFICE_IN_SET=0
declare -i SHOW_USERS_WITHOUT_TELEPHONES=1
declare -i SHOW_ONLY_USERS_WITHOUT_TELEPHONES=1

while getopts "thvw" opt; do
  case ${opt} in
    h) SHOW_HELP_SCREEN="$OPTARG"

	SHOW_HELP_SCREEN=1
      ;;
    v) CURL_OUTPUT_MODE=""
      ;;
    t) SHOW_USERS_WITHOUT_TELEPHONES=0
      ;;
    w) SHOW_ONLY_USERS_WITHOUT_TELEPHONES=1
      ;;
  esac
done

if [ $SHOW_ONLY_USERS_WITHOUT_TELEPHONES -eq 1 ]
then

	if [ $SHOW_USERS_WITHOUT_TELEPHONES -eq 0 ]
	then
	SHOW_ONLY_USERS_WITHOUT_TELEPHONES=0
	fi
fi

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"

### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "List All Users without Office Phones in a GroupWise System Script"
echo ""
echo "Script usage:   $0 [options]"
echo ""
echo "Example:        $0"
echo ""
echo "Verbose Mode:   $0 -v"
echo ""
echo "Help:           $0 -h"
echo ""
}

### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
	GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then

echo "GW_ADMIN_SERVICE_ADDRESS=\"172.0.0.0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}

echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then

GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"

fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}
fi

}

function CHECK_GWADMIN_SERVICE()
{

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

CURL_TRY=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

AUTHENTICATION_WORKED=`echo $?`

if [ ${AUTHENTICATION_WORKED} -ne 0 ]
then
echo ""
echo "Error authenticating to GroupWise Admnistration Service"
echo ""
exit 1
fi

}


function REPORT_TITLES()
{

TEMP_FILE_ONE=$1

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.22.tmp"


grep -v "name,givenName,surname,telephoneNumber,postoffice" $TEMP_FILE_ONE 1> $TEMP_FILE_TWO 


# Add an additional line to the file

while read CURRENT_LINE
do

USER_NAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $1}'`

FIRST_NAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $2}'`

LAST_NAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $3}'`

PHONE=`echo "${CURRENT_LINE}" | awk -F , '{printf $4}'`

POST_OFFICE=`echo "${CURRENT_LINE}" | awk -F , '{printf $5}'`

PHONE_LENGTH=`echo "${PHONE}" | wc -m` 

if [ $PHONE_LENGTH -lt 2 ]
then

	if [ $SHOW_USERS_WITHOUT_TELEPHONES -eq 0 ]
	then
	continue
	fi

PHONE="[ no phone specified ]"
fi

if [ $SHOW_ONLY_USERS_WITHOUT_TELEPHONES -eq 0 ]
then
echo "USERID: ${USER_NAME}"
echo "NAME:   ${FIRST_NAME} ${LAST_NAME}"
echo "PHONE:  ${PHONE}"
echo "POST OFFICE: ${POST_OFFICE}"
echo ""
else
	if [ $PHONE_LENGTH -lt 2 ]
	then
	echo "USERID: ${USER_NAME}"
	echo "NAME: ${FIRST_NAME} ${LAST_NAME}"
	echo "PHONE: ${PHONE}"
	echo "POST OFFICE: ${POST_OFFICE}"
	echo ""
	fi
fi

done < ${TEMP_FILE_TWO}

rm $TEMP_FILE_ONE 2> /dev/null

rm $TEMP_FILE_TWO 2> /dev/null

echo ""

}

### Primary Function ###
function LIST_TELEPHONES_IN_SYSTEM()
{
#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/list/user.csv?attrs=name,givenName,surname,telephoneNumber,postoffice"

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

{
curl --silent -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${BASEURL} -o ${TEMP_FILE_TWO}
} 1> /dev/null 2> ${TEMP_FILE_ONE}

declare -i EXIT_STATUS=`wc -m  ${TEMP_FILE_ONE} | awk '{printf $1}'`

if [ $EXIT_STATUS -ne 0 ]
then
echo ""
echo "Cannot List Office Phones"
echo ""
exit 1
fi

rm ${TEMP_FILE_ONE} 2> /dev/null

if [ $SHOW_ONLY_USERS_WITHOUT_TELEPHONES -eq 0 ]
then
echo ""
echo "All Office Phone Numbers in the GroupWise System"
echo ""
else
echo 
echo ""
echo "All Users in The GroupWise System Without Office Phone Numbers"
echo ""
fi



REPORT_TITLES ${TEMP_FILE_TWO}


}

main()
{
if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi


PROCESS_SETTINGS_FILES
CHECK_GWADMIN_SERVICE
LIST_TELEPHONES_IN_SYSTEM
}

main




