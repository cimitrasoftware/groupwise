#!/bin/bash
###########################################
# gw_user_common_fields.sh                #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.5                            #
# Modify date: 1/18/2021                  #
###########################################
# Allows for Changing an eDirectory User's Title, Department, Phone Number, Fax Number, and Postal Address Fields

declare ORIGINAL_SCRIPT_INPUT="$@"

declare INPUT_TYPE_TEXT=""
declare LDAP_OBJECT_NAME=""
declare HELP_EXAMPLE=""
declare -i LDAP_OBJECT_FOUND=0

declare INPUT_IN=""
declare GW_SCRIPT_EXCLUDE_FILE=""
declare CURL_OUTPUT_MODE="--silent"
declare -i ALL_SET=0
declare -i SHOW_HELP_SCREEN=0

declare FULL_NETWORK_ID=""
declare EDIR_SCRIPT_SETTINGS_FILE=""

declare -i USER_IN_SET=0
declare -i INPUT_IN_SET=0

declare USERID_IN=""
declare -i EXCLUDE_GROUP_OFF=0
declare -i TITLE_IN_SET=0
declare -i DEPARTMENT_IN_SET=0
declare -i FAX_NUMBER_IN_SET=0
declare -i PHONE_NUMBER_IN_SET=0
declare -i STREET_IN_SET=0
declare -i CITY_IN_SET=0
declare -i POST_OFFICE_BOX_IN_SET=0
declare -i STATE_IN_SET=0
declare -i ZIP_CODE_IN_SET=0
declare USER_ID_IN=""
declare USERID_IN_LOWER=""

while [ "$#" -gt 0 ]
do
    case "$1" in
    -u)
     USERID_IN="$2" 
     USERID_IN_SET=1
     USERID_IN_LOWER=`echo ${USERID_IN} | tr [A-Z] [a-z]`
     ;;
    -a) TITLE_IN="$2"
	TITLE_IN_SET=1
      ;;
    -b) DEPARTMENT_IN="$2"
	declare -i COMMAND_LINE_HAS_SWITCH=`echo "${DEPARTMENT_IN}" | grep -c "\-c"`
	if [ $COMMAND_LINE_HAS_SWITCH -eq 0 ]
	then
	DEPARTMENT_IN_SET=1
	fi
       ;;
    -c) PHONE_NUMBER_IN="$2"
	declare -i COMMAND_LINE_HAS_SWITCH=`echo "${PHONE_NUMBER_IN}" | grep -c "\-d"`
	if [ $COMMAND_LINE_HAS_SWITCH -eq 0 ]
	then
	PHONE_NUMBER_IN_SET=1
	fi
       ;;
    -d) FAX_NUMBER_IN="$2"
	declare -i COMMAND_LINE_HAS_SWITCH=`echo "${FAX_NUMBER_IN}" | grep -c "\-f"`
	if [ $COMMAND_LINE_HAS_SWITCH -eq 0 ]
	then
	FAX_NUMBER_IN_SET=1
	fi
	;;
    -f) STREET_IN="$2"
	declare -i COMMAND_LINE_HAS_SWITCH=`echo "${STREET_IN}" | grep -c "\-g"`

	if [ $COMMAND_LINE_HAS_SWITCH -eq 0 ]
	then
	STREET_IN_SET=1
	fi
      ;;
    -g) POST_OFFICE_BOX_IN="$2"
	declare -i COMMAND_LINE_HAS_SWITCH=`echo "${POST_OFFICE_BOX_IN}" | grep -c "\-j"`

	if [ $COMMAND_LINE_HAS_SWITCH -eq 0 ]
	then
	POST_OFFICE_BOX_IN_SET=1
	fi
      ;;
    -j) CITY_IN="$2"
	declare -i COMMAND_LINE_HAS_SWITCH=`echo "${CITY_IN}" | grep -c "\-k"`

	if [ $COMMAND_LINE_HAS_SWITCH -eq 0 ]
	then
	CITY_IN_SET=1
	fi
      ;;
    -k) STATE_IN="$2"
	declare -i COMMAND_LINE_HAS_SWITCH=`echo "${STATE_IN}" | grep -c "\-l"`

	if [ $COMMAND_LINE_HAS_SWITCH -eq 0 ]
	then
	STATE_IN_SET=1
	fi
      ;;
    -l) ZIP_CODE_IN="$2"
	ZIP_CODE_IN_SET=1
      ;;
    -p) POST_OFFICE_IN="$2"
	POST_OFFICE_IN_SET=1
      ;;
    -i) INPUT_IN="$OPTARG"
	INPUT_IN_SET=1
      ;;
    -s) SKIP_LDAP_ASSOCIATION_CHECK=1
      ;;
    -e) EXCLUDE_GROUP_OFF=1
      ;;
    -h) SHOW_HELP_SCREEN=1
	USERID_IN_LOWER=`echo ${USERID_IN} | tr [A-Z] [a-z]`
      ;;
    -v) CURL_OUTPUT_MODE=""
      ;;
    esac
	shift
done


SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"


### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "GroupWise User ${INPUT_TYPE_TEXT} Change Script"
echo ""
echo "Script usage:      $0 [options]"
echo ""
echo "Example:           $0 -p <post office> -u <GroupWise userid> -a "Title" -b "Department" -c "Phone Number" -d "Fax Number" -f "Street" -g "Post Office Box" -j "City" -k "State" -l "Zip Code">"
echo ""
echo "Example:           $0 -p po1 -u jdoe -i ${HELP_EXAMPLE}"
echo ""
echo "Verbose Mode:      $0 -v -p <post office> -u <GroupWise userid> -a "Title" -b "Department" -c "Phone Number" -d "Fax Number">"
echo ""
echo "Skip LDAP:         $0 -s ... | Skip user association check in eDirectory�"
echo ""
echo "Disable Multiple userid Input:  $0  -m ..."
echo ""
echo "Help:              $0 -h"
echo ""
}


### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then
echo "GW_ADMIN_SERVICE_ADDRESS=\"172.0.0.0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then
GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"
fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}
fi

}

function PROCESS_EDIR_SETTINGS()
{

if [ $LDAP_OBJECT_FOUND -eq 1 ]
then
return
fi

GW_ADMIN_USER='admin_level_user'
declare -i GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT=0
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
LDAP_OBJECT_FOUND=1
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


if [[ ${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT} -eq 0 ]]
then
echo "GW_EDIR_ADMIN_USER=\"cn=admin,o=cimitra\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EDIR_ADMIN_PASSWORD=\"eDirLetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS=\"172.0.0.1\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT=\"389\"" >> ${GW_SCRIPT_SETTINGS_FILE}
fi

}


function CHECK_GWADMIN_SERVICE()
{

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

CURL_TRY=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

AUTHENTICATION_WORKED=`echo $?`

if [ ${AUTHENTICATION_WORKED} -ne 0 ]
then
echo ""
echo "Error: Cannot authenticate to GroupWise Administration Service"
echo ""
exit 1
fi

}

# Process exclusions file
function PROCESS_EXCLUSIONS()
{

if [ $EXCLUDE_GROUP_OFF -eq 1 ]
then
return
fi


declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo ""
echo "Error: Exclusions Check File does not exist"
echo ""
return
fi

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`

if [ -z "${USER_RECORD}" ]
then
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo ""
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
echo ""
exit 1
fi

done < ${GW_SCRIPT_EXCLUDE_FILE}

}

function GET_EXCLUDE_GROUP_MEMBERSHIP()
{

if [ $EXCLUDE_GROUP_OFF -eq 1 ]
then
return
fi

declare -i GW_EXCLUDE_GROUP_ENABLED=0

source ${GW_SCRIPT_SETTINGS_FILE}

if [ $GW_EXCLUDE_GROUP_ENABLED -eq 0 ]
then
return
fi

if [ ${GW_EXCLUDE_GROUP_NAME} == 'exclude_group_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_POST_OFFICE_NAME} == 'exclude_group_post_office_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's post office name"
echo ""
exit 1
fi

if [ ${GW_EXCLUDE_GROUP_DOMAIN_NAME} == 'exclude_group_domain_name_here' ]
then
echo ""
echo "Error: Please properly configure exclude group's domain name"
echo ""
exit 1
fi


BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="domains/${GW_EXCLUDE_GROUP_DOMAIN_NAME}/postoffices/${GW_EXCLUDE_GROUP_POST_OFFICE_NAME}/groups/${GW_EXCLUDE_GROUP_NAME}/members"

GROUP_GET_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

GROUP_GET_WORKED=`echo $?`

if [ ${GROUP_GET_WORKED} -ne 0 ]
then
echo ""
echo "Error getting exclude group information"
echo ""
exit 1
fi

declare -i GROUP_GET_OBJECT_HAS_COUNTER=`echo "${GROUP_GET_OBJECT}" | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -c "resultInfo:outOf:"`

if [ $GROUP_GET_OBJECT_HAS_COUNTER -ne 1 ]
then
echo ""
echo "Error getting exclude group membership count[1]"
echo ""
exit 1
fi

declare -i GROUP_GET_OBJECT_COUNTER=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep "resultInfo:outOf:" | awk -F ':' '{printf $3}'`

declare -i NUMBER_OF_USERS_IN_GROUP=`echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -ce "^name:"`

if ! [[ "${GROUP_GET_OBJECT_COUNTER}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [2]"
echo ""
exit 1
fi

if ! [[ "${NUMBER_OF_USERS_IN_GROUP}" =~ ^[0-9]+$ ]]
then
echo ""
echo "Error getting exclude group membership count [3]"
echo ""
exit 1
fi

if [ ${GROUP_GET_OBJECT_COUNTER} -ne ${NUMBER_OF_USERS_IN_GROUP} ]
then
echo ""
echo "Error getting exclude group membership count [4]"
echo ""
exit 1
fi

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

echo ${GROUP_GET_OBJECT} | sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' | grep -e "^name:"  | sed 's/name://' 1> ${TEMP_FILE_ONE}

while read USER_RECORD
do

USER_RECORD_LOWERCASE=`echo "${USER_RECORD}" | tr [A-Z] [a-z]`

if [ -z "${USER_RECORD}" ]
then
# Skip empty lines
continue
fi

if [ ${USERID_IN_LOWER} = ${USER_RECORD_LOWERCASE} ]
then
echo ""
echo "ERROR: Insufficient rights to administer user: ${USERID_IN}"
echo ""
rm ${TEMP_FILE_ONE}
exit 1

fi

done < ${TEMP_FILE_ONE}

rm ${TEMP_FILE_ONE}

}


### Make sure the script is being called with the correct inputs ###
function CONFIRM_CORRECT_INPUT(){

let ALL_SET=USERID_IN_SET+POST_OFFICE_IN_SET

if [ $ALL_SET -ne 2 ]
then
SHOW_HELP
echo ""
echo "NOTE: Insufficient Input To Run Script"
echo ""
exit 1
fi
}

function VERIFY_USER_EXISTENCE()
{

source ${GW_SCRIPT_SETTINGS_FILE}

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"
{
USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -ne 0 ]
then
echo ""
echo "Error: Userid: ${USERID_IN} Does not Exist in Post Office: ${POST_OFFICE_IN}"
echo ""
exit 1
fi
}


function SYNC_GROUPWISE_USER_OBJECT()
{

#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"
{
URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3"/mailboxstats"}'`

TEST=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -ne 0 ]
then
echo ""
echo "Error: Cannot establish connection to GroupWise Admin Service"
echo ""
exit 1
fi

USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`

USER_DOMAIN=`echo "${USER_OBJECT}" | grep -Po '"domainName":"\K[^"]*'`

SYNC_URL="$BASEURL/domains/${USER_DOMAIN}/postoffices/${POST_OFFICE_IN}/users/${USERID_IN}/directorylink/sync"

{
DO_SYNC=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X POST ${SYNC_URL}` 1> /dev/null
} 1> /dev/null 2> /dev/null

}


function GET_GROUPWISE_EDIR_USER_OBJECT()
{

if [ $LDAP_OBJECT_FOUND -eq 1 ]
then
return
fi

#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"
{
URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3"/mailboxstats"}'`

TEST=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -ne 0 ]
then
echo ""
echo "Error: Cannot establish connection to GroupWise Admin Service"
echo ""	
exit 1
fi

USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`

declare -i USER_HAS_LDAP_TREE=`echo "${USER_OBJECT}" | grep -c "directoryId"`


if [ $USER_HAS_LDAP_TREE -eq 0 ]
then
echo ""
echo "Error: Cannot discover eDirectory tree for GroupWise account ${USERID_IN}"
echo ""
exit 1
fi

declare -i CN_EXISTS=`echo "${USER_OBJECT}" | grep -cPo '"ldapDn":"\K[^"]*'`

if [ $CN_EXISTS -eq 1 ]
then
FULL_NETWORK_ID=`echo "${USER_OBJECT}" | grep -Po '"ldapDn":"\K[^"]*'`
else
declare -i USER_HAS_NETWORK_ID=`echo "${USER_OBJECT}" | grep -c "networkId"`

	if [ $USER_HAS_NETWORK_ID -eq 1 ]
	then
	NETWORK_ID_ONE=`echo "${USER_OBJECT}" | grep -Po '"networkId":"\K[^"]*'`
	NETWORK_ID_TWO=`echo "${NETWORK_ID_ONE}" | sed -r 's/(.*)\./\1,o=/'`
	NETWORK_ID_THREE=`echo "${NETWORK_ID_TWO}" | sed 's/\./,ou=/g'`
	FULL_NETWORK_ID="cn=${NETWORK_ID_THREE}"
	else
	echo ""
	echo "Error: Cannot discover network ID for GroupWise account ${USERID_IN}"
	echo ""	
	exit 1
	fi

fi

}


### Primary Function for User Attribute Edit ###
function CHANGE_USER_EDIR_ATTRIBUTE()
{
# --- Create ldif data for the setting change

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp.ldif"

echo "dn: ${FULL_NETWORK_ID}" 1> ${TEMP_FILE_ONE}
echo "changetype: Modify" 1>> ${TEMP_FILE_ONE}
echo "replace: ${LDAP_OBJECT_NAME}" 1>> ${TEMP_FILE_ONE}
echo "${LDAP_OBJECT_NAME}: ${INPUT_IN}" 1>> ${TEMP_FILE_ONE}

source ${GW_SCRIPT_SETTINGS_FILE}
# --- Now use ldapmodify to change the value

{
ldapmodify -x -h ${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_ADDRESS} -p ${GW_EDIR_LDAP_SERVICE_SIMPLE_AUTHENTICATION_PORT} -w $GW_EDIR_ADMIN_PASSWORD -D $GW_EDIR_ADMIN_USER -f ${TEMP_FILE_ONE}
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

rm ${TEMP_FILE_ONE} 1> /dev/null 2> /dev/null


if [ $EXIT_STATUS -eq 0 ]
then
echo ""
echo "Account ${USERID_IN} ${INPUT_TYPE_TEXT} Set To: ${INPUT_IN}"
echo ""
SYNC_GROUPWISE_USER_OBJECT
else
echo ""
echo "Account ${USERID_IN} ${INPUT_TYPE_TEXT} NOT Set To: ${INPUT_IN}"
echo ""
fi
}




function CHECK_FOR_LDAP_DIRECTORY()
{

if [ $SKIP_LDAP_ASSOCIATION_CHECK -eq 1 ]
then
return
fi

source ${GW_SCRIPT_SETTINGS_FILE}

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"

USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`

declare -i LDAP_DIRECTORY_SPECIFIED=`echo ${USER_OBJECT} | grep -c "directoryId"`

SKIP_GROUPWISE_USER_OBJECT_CHANGE=0

if [ $LDAP_DIRECTORY_SPECIFIED -gt 0 ]
then
PROCESS_EDIR_SETTINGS
GET_GROUPWISE_EDIR_USER_OBJECT
CHANGE_USER_EDIR_ATTRIBUTE
SKIP_GROUPWISE_USER_OBJECT_CHANGE=1
fi

}

function GET_USER_FULL_NAME()
{
#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"
{
URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3"/mailboxstats"}'`

TEST=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${URL}`
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -ne 0 ]
then
return
fi

USER_URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

USER_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${USER_URL}`

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

echo "$USER_OBJECT" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

LAST_NAME=`echo "${USER_OBJECT}" | grep -Po '"surname":"\K[^"]*'`

FIRST_NAME=`echo "${USER_OBJECT}" | grep -Po '"givenName":"\K[^"]*'`

echo ""
echo "FULL NAME:   ${FIRST_NAME} ${LAST_NAME}"

rm ${TEMP_FILE_ONE} 2> /dev/null

rm ${TEMP_FILE_TWO} 2> /dev/null
 
}


### Primary Function for User GroupWise Object Change ###
function CHANGE_USER_GROUPWISE_ATTRIBUTE()
{
#-- Build the base url for admin service
BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

# --- Create json data for the setting change

DATA="{\"${GROUPWISE_OBJECT_NAME}\":\"${INPUT_IN}\"}"

SEARCHURL="$BASEURL/list/user.csv?name=${USERID_IN}&postoffice=${POST_OFFICE_IN}&attrs=domain,postoffice,name"

URL=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${SEARCHURL} | gawk --field-separator=, 'NR!=1 {print "'$BASEURL'/domains/"$1"/postoffices/"$2"/users/"$3""}'`

# --- Now use curl to change the value

{
curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X PUT ${URL} --data "$DATA"
} 1> /dev/null 2> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
echo ""
echo "Account ${USERID_IN} ${INPUT_TYPE_TEXT} Set To: ${INPUT_IN}"
echo ""
else
echo ""
echo "Account ${USERID_IN} ${INPUT_TYPE_TEXT} NOT Set To: ${INPUT_IN}"
echo ""
fi


}

function pre_main()
{

if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi
PROCESS_SETTINGS_FILES
CHECK_GWADMIN_SERVICE
CONFIRM_CORRECT_INPUT
VERIFY_USER_EXISTENCE
PROCESS_EXCLUSIONS
GET_EXCLUDE_GROUP_MEMBERSHIP
GET_USER_FULL_NAME
}

pre_main

function START_UP()
{

echo "---------------------------------"
echo "STARTING UPDATING USER ATTRIBUTES"
echo ""
}

START_UP


main()
{
CHECK_FOR_LDAP_DIRECTORY
if [ $SKIP_GROUPWISE_USER_OBJECT_CHANGE -eq 0 ]
then
CHANGE_USER_GROUPWISE_ATTRIBUTE
fi

}


function PROCESS_TITLE()
{

declare -i COMMAND_LINE_HAS_SWITCH=`echo "${ORIGINAL_SCRIPT_INPUT}" | grep -c "\-a"`

if [ $TITLE_IN_SET -eq 0 ]
then
	if [ $COMMAND_LINE_HAS_SWITCH -eq 0 ]
	then
	return
	fi
fi

if [ -n "$TITLE_IN" ] 
then
:
else
return
fi

if [[ "$TITLE_IN" =~ ^- ]]
then
return
fi

INPUT_TYPE_TEXT="Title"
GROUPWISE_OBJECT_NAME="title"
LDAP_OBJECT_NAME="title"
HELP_EXAMPLE="Accountant"
INPUT_IN="${TITLE_IN}"
main
}

PROCESS_TITLE

function PROCESS_DEPARTMENT()
{

declare -i COMMAND_LINE_HAS_SWITCH=`echo "${ORIGINAL_SCRIPT_INPUT}" | grep -c "\-b"`

if [ $DEPARTMENT_IN_SET -eq 0 ]
then

	if [ $COMMAND_LINE_HAS_SWITCH -eq 0 ]
	then
	return
	fi


fi



if [ -n "$DEPARTMENT_IN" ] 
then
:
else
return
fi

if [[ "$DEPARTMENT_IN" =~ ^- ]]
then
return
fi

INPUT_TYPE_TEXT="Department Name"
GROUPWISE_OBJECT_NAME="department"
HELP_EXAMPLE="Accounting"
LDAP_OBJECT_NAME="ou"
INPUT_IN="${DEPARTMENT_IN}"
main
}

PROCESS_DEPARTMENT


function PROCESS_PHONE()
{

declare -i COMMAND_LINE_HAS_SWITCH=`echo "${ORIGINAL_SCRIPT_INPUT}" | grep -c "\-c"`

if [ $PHONE_NUMBER_IN_SET -eq 0 ]
then
	if [ $COMMAND_LINE_HAS_SWITCH -eq 0 ]
	then
	return
	fi
fi
if [ -n "$PHONE_NUMBER_IN" ] 
then
:
else
return
fi

if [[ "$PHONE_NUMBER_IN" =~ ^- ]]
then
return
fi

INPUT_TYPE_TEXT="Phone Number"
GROUPWISE_OBJECT_NAME="telephoneNumber"
LDAP_OBJECT_NAME="telephoneNumber"
HELP_EXAMPLE="801-555-1212"
INPUT_IN="${PHONE_NUMBER_IN}"
main
}

PROCESS_PHONE


function PROCESS_FAX()
{

declare -i COMMAND_LINE_HAS_SWITCH=`echo "${ORIGINAL_SCRIPT_INPUT}" | grep -c "\-d"`

if [ $FAX_NUMBER_IN_SET -eq 0 ]
then
	if [ $COMMAND_LINE_HAS_SWITCH -eq 0 ]
	then
	return
	fi
fi

if [ -n "$FAX_NUMBER_IN" ] 
then
:
else
return
fi

if [[ "$FAX_NUMBER_IN" =~ ^- ]]
then
return
fi

INPUT_TYPE_TEXT="Fax Number"
GROUPWISE_OBJECT_NAME="faxNumber"
LDAP_OBJECT_NAME="facsimileTelephoneNumber"
HELP_EXAMPLE="801-444-1212"
INPUT_IN="${FAX_NUMBER_IN}"
main
}

PROCESS_FAX

function PROCESS_STREET()
{

if [ $STREET_IN_SET -eq 0 ]
then
return
fi

if [ -n "$STREET_IN" ] 
then
:
else
return
fi

INPUT_TYPE_TEXT="Street"
GROUPWISE_OBJECT_NAME="streetAddress"
LDAP_OBJECT_NAME="street"
HELP_EXAMPLE="Main Street"
INPUT_IN="${STREET_IN}"
main
}

PROCESS_STREET

function PROCESS_POST_OFFICE_BOX()
{

if [ $POST_OFFICE_BOX_IN_SET -eq 0 ]
then
return
fi

if [ -n "$POST_OFFICE_BOX_IN" ] 
then
:
else
return
fi

INPUT_TYPE_TEXT="Post Office Box"
GROUPWISE_OBJECT_NAME="postOfficeBox"
LDAP_OBJECT_NAME="postOfficeBox"
HELP_EXAMPLE="Post Office Box"
INPUT_IN="${POST_OFFICE_BOX_IN}"
main
}

PROCESS_POST_OFFICE_BOX


function PROCESS_CITY()
{

if [ $CITY_IN_SET -eq 0 ]
then
return
fi

if [ -n "$CITY_IN" ] 
then
:
else
return
fi

INPUT_TYPE_TEXT="Location"
GROUPWISE_OBJECT_NAME="city"
LDAP_OBJECT_NAME="physicalDeliveryOfficeName"
HELP_EXAMPLE="Provo"
INPUT_IN="${CITY_IN}"
main
}

PROCESS_CITY


function PROCESS_STATE()
{

if [ $STATE_IN_SET -eq 0 ]
then
return
fi

if [ -n "$STATE_IN" ] 
then
:
else
return
fi

INPUT_TYPE_TEXT="State"
GROUPWISE_OBJECT_NAME="stateProvince"
LDAP_OBJECT_NAME="stateOrProvinceName"
HELP_EXAMPLE="UT"
INPUT_IN="${STATE_IN}"
main
}

PROCESS_STATE

function PROCESS_ZIP_CODE()
{

if [ $ZIP_CODE_IN_SET -eq 0 ]
then
return
fi

if [ -n "$ZIP_CODE_IN" ] 
then
:
else
return
fi

INPUT_TYPE_TEXT="Zip Code"
GROUPWISE_OBJECT_NAME="postalZipCode"
LDAP_OBJECT_NAME="postalCode"
HELP_EXAMPLE="94022"
INPUT_IN="${ZIP_CODE_IN}"
main
}

PROCESS_ZIP_CODE

function WRAP_UP()
{
echo ""
echo "---------------------------------"
echo "FINISHED UPDATING USER ATTRIBUTES"

}

WRAP_UP


