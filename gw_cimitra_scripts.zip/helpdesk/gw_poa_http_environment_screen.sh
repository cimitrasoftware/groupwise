#!/bin/bash
###########################################
# gw_poa_http_environment_screen.sh       #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.4                            #
# Modify date: 1/4/2020                   #
###########################################
# This script captures the POA's Environment Screen in HTML format and redirects it to a file
# This allows the ability to take a screen shot and perhaps host it on a webserver with the need for credentials

declare -i ALL_SET=0
declare -i SHOW_HELP_SCREEN=0
declare GW_SCRIPT_EXCLUDE_FILE=""
declare CURL_OUTPUT_MODE="--silent"
TEMP_FILE_DIRECTORY="/var/tmp"

declare GW_POA_HTTP_USER_NAME=""
declare GW_POA_HTTP_USER_PASSWORD=""

declare -i GW_POA_HTTP_CREDENTIALS_ARE_UNIVERSAL=0

declare -i USER_IN_SET=0
declare -i NEW_PASSWORD_IN_SET=0

declare -i POA_HTTP_PORT_IN_SET=0
declare -i POA_HTTP_ADDRESS_IN_SET=0
declare -i POA_HTTP_INFORMATION_SET=0
declare -i OUTPUT_FILE_IN_SET=0
declare -i POST_OFFICE_DOMAIN_IN_SET=0
declare -i POST_OFFICE_IN_SET=0
declare -i HTML_HEADER_TRIM_AMOUNT=10
declare -i EXIT_SCRIPT_IN_SET=0



while getopts "a:d:e:o:p:t:hvw:" opt; do
  case ${opt} in
    a) POA_HTTP_ADDRESS_IN="$OPTARG"
	POA_HTTP_ADDRESS_IN_SET=1
	;;
    d) POST_OFFICE_DOMAIN_IN="$OPTARG"
	POST_OFFICE_DOMAIN_IN_SET=1
      ;;
    e) EXIT_SCRIPT_IN="$OPTARG"
	EXIT_SCRIPT_IN_SET=1
	;;
    p) POST_OFFICE_IN="$OPTARG"
	POST_OFFICE_IN_SET=1
      ;;
    o) OUTPUT_FILE_IN="$OPTARG"
	OUTPUT_FILE_IN_SET=1
      ;;
    h) SHOW_HELP_SCREEN="$OPTARG"
	SHOW_HELP_SCREEN=1
      ;;
    t) HTML_HEADER_TRIM_AMOUNT="$OPTARG"
	;;
    v) CURL_OUTPUT_MODE=""
      ;;
    w) POA_HTTP_PORT_IN="$OPTARG"
	POA_HTTP_PORT_IN_SET=1
	;;
  esac
done

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"


### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "Screen Scrape POA's HTTP Console Environment Screen
"
echo ""
echo "Script usage: $0 [options]"
echo ""
echo "Example:      $0  -p <post office> -d <post office's domain> -o <output file location and name>"
echo ""
echo "Trim HTML Header Amount: Use -t and then a number. The default is 10 if you do not specify otherwise"
echo ""
echo "Run Exit Script: Use -e <path to a script to run on exit>, for using a script for post-processing"
echo ""
echo "Verbose Mode: $0 -v  -p <post office> -d <post office's domain> -o <output file location and name>"
echo ""
echo "Help:         $0 -h"
echo ""
}

### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then

echo "GW_ADMIN_SERVICE_ADDRESS=\"172.0.0.0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_POA_HTTP_CREDENTIALS_ARE_UNIVERSAL=\"1\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}

echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
exit 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then
GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"
fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then

echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}

fi

}

function PROCESS_HTTP_SETTINGS_FILES()
{

# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable

if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi


declare -i GW_POA_HTTP_CREDENTIALS_ARE_UNIVERSAL=2
source ${GW_SCRIPT_SETTINGS_FILE}

if [ $GW_POA_HTTP_CREDENTIALS_ARE_UNIVERSAL -eq 2 ]
then
echo "GW_POA_HTTP_CREDENTIALS_ARE_UNIVERSAL=\"1\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_POA_HTTP_USER_NAME=\"poa_http_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_POA_HTTP_USER_PASSWORD=\"poa_http_user_password\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
echo "Configure the GW_POA_HTTP* variables"
echo ""
exit 1
fi

if [ $GW_POA_HTTP_CREDENTIALS_ARE_UNIVERSAL -eq 0 ]
then
POST_OFFICE_IN_LOWER=`echo "${POST_OFFICE_IN}" | tr [A-Z] [a-z]`
POA_HTTP_CONFIGURATION_FILE="${SCRIPT_PATH}/${POST_OFFICE_IN_LOWER}.poa.cfg"

declare -i POA_HTTP_CONFIGURATION_FILE_EXISTS=`ls ${POA_HTTP_CONFIGURATION_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`
	
	if [ $POA_HTTP_CONFIGURATION_FILE_EXISTS -eq 1 ]
	then
	echo "GW_POA_HTTP_USER_NAME=\"poa_http_user\"" >> ${POA_HTTP_CONFIGURATION_FILE}
	echo "GW_POA_HTTP_USER_PASSWORD=\"poa_http_user_password\"" >> ${POA_HTTP_CONFIGURATION_FILE}
	echo ""
       echo "Please configure the GroupWise POA Settings file: ${POA_HTTP_CONFIGURATION_FILE}"
	echo ""
	echo "Configure the GW_POA_HTTP* variables"
	echo ""
	exit 1
	else

	GW_POA_HTTP_USER_NAME='poa_http_user'
	# Read the POA_HTTP_CONFIGURATION_FILE file
	source ${POA_HTTP_CONFIGURATION_FILE}

		if [[ ${GW_POA_HTTP_USER_NAME} = 'poa_http_user' ]]
		then
		echo ""
       	echo "Please configure the GroupWise POA Settings file: ${POA_HTTP_CONFIGURATION_FILE}"
		echo ""
		echo "Configure the GW_POA_HTTP* variables"
		echo ""
		exit 1
		fi

	fi
else

GW_POA_HTTP_USER_NAME='poa_http_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}
	if [[ ${GW_POA_HTTP_USER_NAME} = 'poa_http_user' ]]
	then
	echo ""
	echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
	echo ""
	echo "Configure the GW_POA_HTTP* variables"
	echo ""
	exit 1
	fi



fi

}

function CHECK_GWADMIN_SERVICE()
{

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

CURL_TRY=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

AUTHENTICATION_WORKED=`echo $?`

if [ ${AUTHENTICATION_WORKED} -ne 0 ]
then
echo ""
echo "Error authenticating to GroupWise Admnistration Service"
echo ""
exit 1
fi

}


### Make sure the script is being called with the correct inputs ###
function CONFIRM_CORRECT_INPUT(){

let ALL_SET=OUTPUT_FILE_IN_SET+POST_OFFICE_IN_SET+POST_OFFICE_DOMAIN_IN_SET

if [ $ALL_SET -ne 3 ]
then
SHOW_HELP
echo ""
echo "NOTE: Insufficient Input To Run Script"
echo ""
exit 1
fi
}


### Primary Function###
function SCRAPE_POA_HTTP_CONSOLE()
{

declare -i POA_HTTP_PORT_IN_SET=0
declare -i POA_HTTP_ADDRESS_IN_SET=0
declare -i POA_HTTP_INFORMATION_SET=0

let POA_HTTP_INFORMATION_SET=POA_HTTP_PORT_IN_SET+POA_HTTP_ADDRESS_IN_SET

if [ $POA_HTTP_INFORMATION_SET -ne 2 ]
then

BASE_REST_URL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="domains/${POST_OFFICE_DOMAIN_IN}/postoffices/${POST_OFFICE_IN}/poas/poa"

POA_URL="${BASE_REST_URL}/${ENDPOINT}"

{
POA_OBJECT=`curl ${CURL_OUTPUT_MODE} -k --user $GW_ADMIN_USER:$GW_ADMIN_PASSWORD -H "Content-Type:application/json" -X GET ${POA_URL}`
} 1> /dev/null 2> /dev/null


TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

TEMP_FILE_THREE="${TEMP_FILE_DIRECTORY}/$$.3.tmp"

echo "${POA_OBJECT}" 1> ${TEMP_FILE_ONE}

sed -e 's/[}"]*\(.\)[{"]*/\1/g;y/,/\n/' < ${TEMP_FILE_ONE} > ${TEMP_FILE_TWO}

POA_HTTP_IP_ADDRESS=`cat ${TEMP_FILE_TWO} | grep ipAddress | awk -F : '{printf $2}'`

POA_HTTP_PORT=`cat ${TEMP_FILE_TWO} | grep httpPort | awk -F : '{printf $2}'`

rm ${TEMP_FILE_ONE} 

rm ${TEMP_FILE_TWO}

fi

PROCESS_HTTP_SETTINGS_FILES

if [ $POA_HTTP_ADDRESS_IN_SET -eq 0 ]
then
GW_POA_HTTP_ADDRESS="${POA_HTTP_IP_ADDRESS}"
else
GW_POA_HTTP_ADDRESS="${POA_HTTP_ADDRESS_IN}"
fi

if [ $POA_HTTP_PORT_IN_SET -eq 0 ]
then
GW_POA_HTTP_PORT="${POA_HTTP_PORT}"
else
GW_POA_HTTP_PORT="${POA_HTTP_PORT_IN}"
fi

BASE_POA_URL="https://${GW_POA_HTTP_ADDRESS}:${GW_POA_HTTP_PORT}/server"

{
curl -s -i -X GET -k --user ${GW_POA_HTTP_USER_NAME}:${GW_POA_HTTP_USER_PASSWORD} ${BASE_POA_URL} -H "Content-Type: application/x-www-form-urlencoded" -o ${TEMP_FILE_THREE}
} 2> /dev/null 1> /dev/null

declare -i EXIT_STATUS=`echo $?`

if [ $EXIT_STATUS -eq 0 ]
then
:
else
echo ""
echo "Error: Cannot Log into POA HTTP Console"
echo ""
exit 1
fi

tail -n +${HTML_HEADER_TRIM_AMOUNT} ${TEMP_FILE_THREE} 1> ${OUTPUT_FILE_IN}

rm ${TEMP_FILE_THREE}


echo ""
echo "Got POA Web Console Information"
echo ""

if [ $EXIT_SCRIPT_IN_SET -eq 1 ]
then
$(source ${EXIT_SCRIPT_IN} ${OUTPUT_FILE_IN}) 
fi




}


main()
{
if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi

CONFIRM_CORRECT_INPUT
PROCESS_SETTINGS_FILES
CHECK_GWADMIN_SERVICE
SCRAPE_POA_HTTP_CONSOLE
}

main




