#!/bin/bash
###########################################
# gw_po_remove_nickame.sh                 #
# Author: Tay Kratzer - tay@cimitra.com   #
# Version: 1.4                            #
# Modify date: 12/30/2020                 #
###########################################
# Allows removing a user nickname in a GroupWise post office

declare -i SHOW_HELP_SCREEN=0
declare CURL_OUTPUT_MODE="--silent"
TEMP_FILE_DIRECTORY="/var/tmp"

declare -i INPUT_IN_SET=0
declare -i POST_OFFICE_IN_SET=0
declare -i SHOW_USERS_WITHOUT_NICKNAMES=1
declare -i SHOW_ONLY_USERS_WITHOUT_NICKNAMES=0
declare -i ALLOW_MULTIPLE_WORD_INPUT=1

while getopts "mi:p:hv" opt; do
  case ${opt} in
    h) SHOW_HELP_SCREEN="$OPTARG"

	SHOW_HELP_SCREEN=1
      ;;
    v) CURL_OUTPUT_MODE=""
      ;;
    m) ALLOW_MULTIPLE_WORD_INPUT=0
      ;;
    i) INPUT_IN="$OPTARG"
	INPUT_IN_SET=1
      ;;
    p) POST_OFFICE_IN="$OPTARG"
	POST_OFFICE_IN_SET=1
      ;;

  esac
done

SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"

if [ $ALLOW_MULTIPLE_WORD_INPUT -eq 1 ]
then
INPUT_IN=`echo "$@" | awk -F \-i '{printf $2}' | awk -F \-i '{printf $1}'`

INPUT_IN="$(echo -e "${INPUT_IN}" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"


declare -i NUMBER_OF_INPUT_SPACES=`echo ${INPUT_IN} | tr -cd ' \t' | wc -c`

	if [ $NUMBER_OF_INPUT_SPACES -gt 0 ]
	then

	declare -i INPUT_SET_TEST=`echo "$@" | grep -c '\-i'`


		if [ $INPUT_SET_TEST -eq 1 ]
		then
	
		INPUT_IN_LENGTH=${#INPUT_IN}

			if [ $INPUT_IN_LENGTH -lt 1 ]
			then
			echo ""
			echo "Error: ${INPUT_TYPE_TEXT} not entered"
			echo ""
			exit 1
			else
			INPUT_IN_SET=1
			fi
		fi
	else

		declare -i INPUT_SWITCH_USED=`echo "$@" | grep -c '\-i'`

		if [ $INPUT_SWITCH_USED -eq 1 ]
		then

		INPUT_IN_LENGTH=${#INPUT_IN}

			if [ $INPUT_IN_LENGTH -lt 1 ]
			then
			echo ""
			echo "Error: ${INPUT_TYPE_TEXT} not entered"
			echo ""
			exit 1
			else
			INPUT_IN_SET=1
			fi
		
		else
		:
		fi

	fi

fi


### Help Screen ###
function SHOW_HELP()
{
echo "--- Script Help ---"
echo ""
echo "Remove a Nickname in a GroupWise System Script"
echo ""
echo "Script usage:   $0 [options]"
echo ""
echo "Example:        $0 -p po1 -i <nickname>"
echo ""
echo "Verbose Mode:   $0 -v"
echo ""
echo "Help:           $0 -h"
echo ""
}

### Discover or establish a settings_gw.cfg file ###
function PROCESS_SETTINGS_FILES()
{
# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
	GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

# Test and see if the GW_SCRIPT_SETTINGS_FILE file exists
declare -i GW_SCRIPT_SETTINGS_FILE_EXISTS=`ls ${GW_SCRIPT_SETTINGS_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_SETTINGS_FILE does not exist, initialize it with variables
if [ $GW_SCRIPT_SETTINGS_FILE_EXISTS -ne 0 ]
then

echo "GW_ADMIN_SERVICE_ADDRESS=\"172.0.0.0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_SERVICE_PORT=\"9710\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_USER=\"admin_level_user\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_ADMIN_PASSWORD=\"LetMeInOk\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_ENABLED=\"0\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_NAME=\"exclude_group_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_POST_OFFICE_NAME=\"exclude_group_post_office_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "GW_EXCLUDE_GROUP_DOMAIN_NAME=\"exclude_group_domain_name_here\"" >> ${GW_SCRIPT_SETTINGS_FILE}
echo "TEMP_FILE_DIRECTORY=\"/var/tmp\"" >> ${GW_SCRIPT_SETTINGS_FILE}

echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi

GW_ADMIN_USER='admin_level_user'
# Read the GW_SCRIPT_SETTINGS_FILE file
source ${GW_SCRIPT_SETTINGS_FILE}

if [[ ${GW_ADMIN_USER} = 'admin_level_user' ]]
then
echo ""
echo "Please configure the GroupWise Script Settings file: ${GW_SCRIPT_SETTINGS_FILE}"
echo ""
exit 1
fi


# See if a GW_SCRIPT_EXCLUDE_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_EXCLUDE_FILE}" ]] 
then

GW_SCRIPT_EXCLUDE_FILE="${SCRIPT_PATH}/exclude_gw.cfg"

fi

# Test and see if the GW_SCRIPT_EXCLUDE_FILE file exists
declare -i GW_SCRIPT_EXCLUDE_FILE_EXISTS=`ls ${GW_SCRIPT_EXCLUDE_FILE} 2> /dev/null 1> /dev/null && echo "0" || echo "1"`

# If the GW_SCRIPT_EXCLUDE_FILE does not exist, initialize it
if [ $GW_SCRIPT_EXCLUDE_FILE_EXISTS -ne 0 ]
then
echo "${GW_ADMIN_USER}" >> ${GW_SCRIPT_EXCLUDE_FILE}
fi

}

### Make sure the script is being called with the correct inputs ###
function CONFIRM_CORRECT_INPUT(){

let ALL_SET=POST_OFFICE_IN_SET+INPUT_IN_SET

if [ $ALL_SET -ne 2 ]
then
SHOW_HELP
echo ""
echo "NOTE: Insufficient Input To Run Script"
echo ""
exit 1
fi
}

function CHECK_GWADMIN_SERVICE()
{

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="system/adminservices"

CURL_TRY=`curl ${CURL_OUTPUT_MODE} -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X GET ${BASEURL}/${ENDPOINT} -H "Content-Type: application/json"`

AUTHENTICATION_WORKED=`echo $?`

if [ ${AUTHENTICATION_WORKED} -ne 0 ]
then
echo ""
echo "Error authenticating to GroupWise Admnistration Service"
echo ""
exit 1
fi

}


function REMOVE_NICKNAME()
{

TEMP_FILE_ONE=$1

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.22.tmp"

grep -wi "${INPUT_IN}" $TEMP_FILE_ONE | head -1 1> $TEMP_FILE_TWO 

# Add an additional line to the file

while read CURRENT_LINE
do

NICKNAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $1}'`

PROGRAMATIC_NICKNAME=`echo "${INPUT_IN}" | sed 's/ /%20/g'`

FIRST_NAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $2}'`

LAST_NAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $3}'`

USERNAME=`echo "${CURRENT_LINE}" | awk -F , '{printf $4}'`

POST_OFFICE=`echo "${CURRENT_LINE}" | awk -F , '{printf $5}'`

DOMAIN=`echo "${CURRENT_LINE}" | awk -F , '{printf $6}'`

POST_OFFICE_REPORT_LOWER=`echo "${POST_OFFICE}" | tr [A-Z] [a-z]`

POST_OFFICE_IN_LOWER=`echo "${POST_OFFICE_IN}" | tr [A-Z] [a-z]`

if [ $POST_OFFICE_REPORT_LOWER != $POST_OFFICE_IN_LOWER ]
then

rm $TEMP_FILE_ONE 2> /dev/null

rm ${TEMP_FILE_TWO} 2> /dev/null

echo ""
echo "DID NOT Successfully Remove Nickname: ${INPUT_IN}"
echo ""

return 1

fi

echo ""
echo ""
echo "NICKNAME:    ${NICKNAME}"
echo "USERNAME:    ${USERNAME}"
echo "POST OFFICE: ${POST_OFFICE}"
echo "DOMAIN:      ${DOMAIN}"
echo ""

done < ${TEMP_FILE_TWO}

rm $TEMP_FILE_ONE 2> /dev/null

rm ${TEMP_FILE_TWO} 2> /dev/null

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service"

ENDPOINT="/domains/${DOMAIN}/postoffices/${POST_OFFICE_IN}/nicknames/${PROGRAMATIC_NICKNAME}"

URL="${BASEURL}${ENDPOINT}" 

# curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X DELETE ${URL} -H "Content-Type: application/json"

{
RESPONSE=`curl -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} -X DELETE ${URL} -H "Content-Type: application/json"`
} 1> /dev/null 2> /dev/null
declare -i RESPONSE_HAS_ERROR=`echo "${RESPONSE}" | grep -c ":404"`

if [ $RESPONSE_HAS_ERROR -gt 0 ]
then
echo ""
echo "DID NOT Successfully Remove Nickname: ${INPUT_IN}"
echo ""
else
echo "Successfully Removed Nickname: ${INPUT_IN}"
echo ""
fi

}

### Primary Function ###
function GET_NICKNAMES_IN_SYSTEM()
{
#-- Build the base url for admin service

BASEURL="https://${GW_ADMIN_SERVICE_ADDRESS}:${GW_ADMIN_SERVICE_PORT}/gwadmin-service/list/nickname.csv?attrs=name,givenName,surname,username,postoffice,domain"

TEMP_FILE_ONE="${TEMP_FILE_DIRECTORY}/$$.1.tmp"

TEMP_FILE_TWO="${TEMP_FILE_DIRECTORY}/$$.2.tmp"

{
curl --silent -k --user ${GW_ADMIN_USER}:${GW_ADMIN_PASSWORD} ${BASEURL} -o ${TEMP_FILE_TWO}
} 1> /dev/null 2> ${TEMP_FILE_ONE}

declare -i EXIT_STATUS=`wc -m  ${TEMP_FILE_ONE} | awk '{printf $1}'`

if [ $EXIT_STATUS -ne 0 ]
then
echo ""
echo "Cannot List User Nicknames"
echo ""
exit 1
fi

rm ${TEMP_FILE_ONE} 2> /dev/null

REMOVE_NICKNAME ${TEMP_FILE_TWO} 


}

main()
{
if [ $SHOW_HELP_SCREEN -eq 1 ]
then
SHOW_HELP
exit 0
fi

CONFIRM_CORRECT_INPUT
PROCESS_SETTINGS_FILES
CHECK_GWADMIN_SERVICE
GET_NICKNAMES_IN_SYSTEM
}

main




