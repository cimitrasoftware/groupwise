#!/bin/bash

TEST=`tty | sed -e "s/.*tty\(.*\)/\1/"`

declare -i TEST_HAS_DEV=`echo "$TEST" | grep -c "/dev"`

if [ $TEST_HAS_DEV -gt 0 ]
then
echo "Terminal"
else
echo "No Terminal"
fi