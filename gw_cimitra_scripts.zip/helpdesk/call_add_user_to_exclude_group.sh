#!/bin/bash
# NOT WORKING YET
 
SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"

ADD_USER_TO_GROUP_SCRIPT="gw_group_add_user.sh"

declare -i SCRIPT_EXISTS=`test -f ${SCRIPT_PATH}/${ADD_USER_TO_GROUP_SCRIPT} ; echo $?`

if [ $SCRIPT_EXISTS -ne 0 ]
then
echo ""
echo "Error: The Script ${SCRIPT_PATH}/${ADD_USER_TO_GROUP_SCRIPT} Does Not Exist"
echo ""
exit 1
fi

EXCLUDE_GROUP_IN=$1


POST_OFFICE_IN=$2

PO_IN=`echo ${POST_OFFICE_IN// /}`

if [ -z "$PO_IN" ]
then
echo ""
echo "Error:   Specify The Exclude Group Post Office"
echo "" 
echo "Example: $0 CIMITRA_EXCLUDE po1"
echo ""
exit 1
fi

DOMAIN_IN=$2

DOM_IN=`echo ${DOMAIN_IN// /}`

if [ -z "$DOM_IN" ]
then
echo ""
echo "Error:   Specify The Exclude Group Domain"
echo "" 
echo "Example: $0 CIMITRA_EXCLUDE po1 domain1"
echo ""
exit 1
fi

cd ${SCRIPT_PATH}

# See if a GW_SCRIPT_SETTINGS_FILE is defined in an environment variable
if [[ -z "${GW_SCRIPT_SETTINGS_FILE}" ]] 
then
GW_SCRIPT_SETTINGS_FILE="${SCRIPT_PATH}/settings_gw.cfg"
fi

test -f ${GW_SCRIPT_SETTINGS_FILE}

declare -i SETTINGS_FILE_EXISTS=`echo $?`


if [ $SETTINGS_FILE_EXISTS -ne 0 ]
then
echo ""
echo "Error: The Script ${GW_SCRIPT_SETTINGS_FILE} Does Not Exist"
echo ""
exit 1
fi


/bin/bash ./${CONFIGURE_SCRIPT} "CONFIGURE_GW_EXCLUSION_GROUP" "$1" "$2" "$3"

exit 0
